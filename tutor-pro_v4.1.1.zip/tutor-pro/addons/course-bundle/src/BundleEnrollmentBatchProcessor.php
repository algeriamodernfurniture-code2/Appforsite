<?php
/**
 * Batch processor for Course Bundle existing-buyer enrollment.
 *
 * @package TutorPro\CourseBundle
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 4.1.0
 */

namespace TutorPro\CourseBundle;

use Tutor\Migrations\BatchProcessor;
use Tutor\Migrations\Contracts\SingleProcessor;
use TutorPro\CourseBundle\Models\BundleModel;

defined( 'ABSPATH' ) || exit;

/**
 * Class BundleEnrollmentBatchProcessor
 *
 * @since 4.1.0
 */
class BundleEnrollmentBatchProcessor extends BatchProcessor implements SingleProcessor {

	/**
	 * Name of the processor.
	 *
	 * @since 4.1.0
	 *
	 * @var string
	 */
	protected $name = 'Course Bundle Existing-Student Enrollment';

	/**
	 * Action name to invoke wp-cron.
	 *
	 * @since 4.1.0
	 *
	 * @var string
	 */
	protected $action = 'tutor_course_bundle_enroll_existing_students';

	/**
	 * Batch size.
	 *
	 * @since 4.1.0
	 *
	 * @var int
	 */
	protected $batch_size = 50;

	/**
	 * Schedule interval in seconds.
	 *
	 * @since 4.1.0
	 *
	 * @var int
	 */
	protected $schedule_interval = 10;

	/**
	 * Option name where the bundle jobs queue is stored.
	 *
	 * @var string
	 */
	const QUEUE_OPTION = 'tutor_bundle_student_enrollment_queue';

	/**
	 * In-memory cache for the active job, valid for the lifetime of one process_batch() call.
	 * Avoids repeated get_option() DB reads inside get_current_job() per student item.
	 *
	 * @since 4.1.0
	 *
	 * @var array|null
	 */
	private ?array $current_job_cache = null;

	/**
	 * Queue job status constants.
	 *
	 * @since 4.1.0
	 *
	 * @var string
	 */
	const STATUS_QUEUED                  = 'queued';
	const STATUS_PROCESSING              = 'processing';
	const STATUS_COMPLETED               = 'completed';
	const STATUS_COMPLETED_WITH_FAILURES = 'completed_with_failures';

	/**
	 * Add a reconciliation job to the queue and schedule batch processing.
	 *
	 * @since 4.1.0
	 *
	 * @param int   $bundle_id bundle ID.
	 * @param array $course_ids newly added course IDs.
	 *
	 * @return array
	 */
	public function add_to_queue( int $bundle_id, array $course_ids ): array {
		$course_ids = array_values( array_unique( array_map( 'intval', $course_ids ) ) );
		if ( empty( $bundle_id ) || empty( $course_ids ) ) {
			return array();
		}

		$queue = get_option( self::QUEUE_OPTION, array() );
		if ( ! is_array( $queue ) ) {
			$queue = array();
		}

		$job_id = wp_generate_uuid4();
		$job    = array(
			'id'                => $job_id,
			'bundle_id'         => $bundle_id,
			'target_course_ids' => $course_ids,
			'total_items'       => count( BundleModel::get_bundle_enrolled_students( $bundle_id ) ),
			'status'            => self::STATUS_QUEUED,
			'enrolled_count'    => 0,
			'skipped_count'     => 0,
			'failed_count'      => 0,
			'created_at'        => current_time( 'mysql' ),
			'completed_at'      => null,
		);

		$queue[] = $job;
		update_option( self::QUEUE_OPTION, $queue );

		// Reset parent's progress so process_batch() doesn't bail immediately
		// if this processor previously ran to completion (completed = true).
		if ( $this->is_completed() ) {
			$this->reset();
		}

		$this->schedule();

		return $job;
	}

	/**
	 * Get the current active job from the queue.
	 *
	 * @since 4.1.0
	 *
	 * @return array|null
	 */
	public function get_current_job(): ?array {
		if ( null !== $this->current_job_cache ) {
			return $this->current_job_cache;
		}

		$queue = get_option( self::QUEUE_OPTION, array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			return null;
		}

		foreach ( $queue as $job ) {
			if ( ! $this->is_job_done( $job ) ) {
				$this->current_job_cache = $job;
				return $this->current_job_cache;
			}
		}

		return null;
	}

	/**
	 * Check if a job has reached a terminal (done) status.
	 *
	 * @since 4.1.0
	 *
	 * @param array $job job data.
	 *
	 * @return bool
	 */
	private function is_job_done( array $job ): bool {
		$status = $job['status'] ?? '';
		return self::STATUS_COMPLETED === $status || self::STATUS_COMPLETED_WITH_FAILURES === $status;
	}

	/**
	 * Invalidate the in-memory job cache after any queue write.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function invalidate_job_cache(): void {
		$this->current_job_cache = null;
	}

	/**
	 * Get total items to process for current job.
	 *
	 * @since 4.1.0
	 *
	 * @return int
	 */
	protected function get_total_items(): int {
		$job = $this->get_current_job();
		if ( ! $job ) {
			return 0;
		}

		return (int) $job['total_items'];
	}

	/**
	 * Get items to process for current batch.
	 *
	 * @since 4.1.0
	 *
	 * @param int $offset offset.
	 * @param int $limit limit.
	 *
	 * @return array
	 */
	protected function get_items( $offset, $limit ): array {
		$job = $this->get_current_job();
		if ( ! $job ) {
			return array();
		}

		return BundleModel::get_bundle_enrolled_students( (int) $job['bundle_id'], $offset, $limit );
	}

	/**
	 * Process a single student item.
	 *
	 * @since 4.1.0
	 *
	 * @param array|object $item student data.
	 *
	 * @return void
	 */
	public function process_item( $item ): void {
		$job = $this->get_current_job();
		if ( ! $job ) {
			return;
		}

		$bundle_id         = (int) $job['bundle_id'];
		$course_ids        = (array) $job['target_course_ids'];
		$user_id           = is_array( $item ) ? (int) $item['user_id'] : (int) $item->user_id;
		$enrollment_origin = is_array( $item ) ? ( $item['enrollment_origin'] ?? 'standard' ) : ( $item->enrollment_origin ?? 'standard' );
		$subscription_id   = is_array( $item ) ? ( $item['subscription_id'] ?? null ) : ( $item->subscription_id ?? null );

		$enrolled_added = 0;
		$skipped_added  = 0;
		$failed_added   = 0;

		foreach ( $course_ids as $course_id ) {
			$course_id = (int) $course_id;
			if ( BundleModel::ENROLL_ORIGIN_SUBSCRIPTION === $enrollment_origin ) {
				$outcome = BundleModel::enroll_student_to_subscription_course( $bundle_id, $course_id, $user_id, $subscription_id );
			} else {
				$outcome = BundleModel::enroll_student_to_course( $bundle_id, $course_id, $user_id );
			}

			if ( BundleModel::ENROLL_STATUS_ENROLLED === ( $outcome['status'] ?? '' ) ) {
				++$enrolled_added;
			} elseif ( BundleModel::ENROLL_STATUS_SKIPPED === ( $outcome['status'] ?? '' ) ) {
				++$skipped_added;
			} else {
				++$failed_added;
			}
		}

		$this->update_job_stats( $enrolled_added, $skipped_added, $failed_added );
	}

	/**
	 * Update stats on current job in queue.
	 *
	 * @param int $enrolled enrolled count increment.
	 * @param int $skipped skipped count increment.
	 * @param int $failed failed count increment.
	 *
	 * @return void
	 */
	private function update_job_stats( int $enrolled, int $skipped, int $failed ) {
		$queue = get_option( self::QUEUE_OPTION, array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			return;
		}

		foreach ( $queue as &$job ) {
			if ( ! $this->is_job_done( $job ) ) {
				$job['status']          = self::STATUS_PROCESSING;
				$job['enrolled_count'] += $enrolled;
				$job['skipped_count']  += $skipped;
				$job['failed_count']   += $failed;
				break;
			}
		}
		unset( $job );

		update_option( self::QUEUE_OPTION, $queue );
		$this->invalidate_job_cache();
	}

	/**
	 * Actions when current batch processing completes.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	protected function on_complete() {
		$queue = get_option( self::QUEUE_OPTION, array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			return;
		}

		$current_job_finalized = false;
		$has_next              = false;
		foreach ( $queue as &$job ) {
			if ( $this->is_job_done( $job ) ) {
				continue;
			}

			if ( ! $current_job_finalized ) {
				$job['status']         = ( 0 < $job['failed_count'] ) ? self::STATUS_COMPLETED_WITH_FAILURES : self::STATUS_COMPLETED;
				$job['completed_at']   = current_time( 'mysql' );
				$current_job_finalized = true;
			} else {
				$has_next = true;
				break;
			}
		}
		unset( $job );

		$this->invalidate_job_cache();

		// Only touch the queue option when we actually finalized a job.
		if ( ! $current_job_finalized ) {
			return;
		}

		if ( $has_next ) {
			update_option( self::QUEUE_OPTION, $queue );
			// Reset BatchProcessor progress option so next job runs from offset 0.
			$this->reset();
			$this->schedule();
		} else {
			delete_option( self::QUEUE_OPTION );
		}
	}
}
