(()=>{"use strict";var e={};// The module cache
var t={};// The require function
function r(n){// Check if module is in cache
var i=t[n];if(i!==undefined){return i.exports}// Create a new module (and put it into the cache)
var a=t[n]={exports:{}};// Execute the module function
e[n](a,a.exports,r);// Return the exports of the module
return a.exports}// webpack/runtime/rspack_version
(()=>{r.rv=()=>"1.6.5"})();// webpack/runtime/rspack_unique_id
(()=>{r.ruid="bundler=rspack@1.6.5"})();// CONCATENATED MODULE: ./assets/src/js/quiz-type/shared/quiz-a11y.js
/**
 * Shared accessibility helpers for quiz interaction question types.
 *
 * Live announcements, aria-describedby wiring, and keyboard step utilities.
 *
 * @package TutorPro
 * @since 4.0.0
 */var n="tutor-quiz-a11y-live-region";var i="tutor-quiz-a11y-sr-only";/**
 * Ensure a polite live region exists (creates one when missing).
 *
 * @param {HTMLElement|null} container Parent to append the region under.
 * @param {string}           id       Unique element id.
 * @return {HTMLElement|null}
 */function a(e,t){if(!e||!t){return null}var r=document.getElementById(t);if(!r){r=document.createElement("div");r.id=t;r.className=n+" "+i;r.setAttribute("aria-live","polite");r.setAttribute("aria-atomic","true");r.setAttribute("role","status");e.appendChild(r)}return r}/**
 * Announce text through a polite live region.
 *
 * @param {HTMLElement|null} region  Live region element.
 * @param {string}           message Message to announce.
 * @return {void}
 */function o(e,t){if(!e||typeof t!=="string"){return}var r=t.trim();if(!r){return}e.textContent="";if(typeof window.requestAnimationFrame==="function"){window.requestAnimationFrame(function(){e.textContent=r});return}e.textContent=r}/**
 * Merge unique id references into aria-describedby.
 *
 * @param {HTMLElement|null} controlEl Focusable control.
 * @param {string[]}         ids       Element ids to describe the control.
 * @return {void}
 */function u(e,t){if(!e||!Array.isArray(t)||!t.length){return}var r=t.filter(function(e){return typeof e==="string"&&e.length>0&&document.getElementById(e)});if(!r.length){return}var n=(e.getAttribute("aria-describedby")||"").split(/\s+/).filter(Boolean);var i=[];var a={};for(var o=0;o<n.length;o++){if(!a[n[o]]){a[n[o]]=true;i.push(n[o])}}for(var u=0;u<r.length;u++){if(!a[r[u]]){a[r[u]]=true;i.push(r[u])}}e.setAttribute("aria-describedby",i.join(" "))}/**
 * Normalize a keyboard event key (with legacy keyCode fallback).
 *
 * @param {KeyboardEvent|null} event Keyboard event.
 * @return {string}
 */function f(e){if(!e){return""}if(e.key&&e.key!=="Unidentified"){return e.key}var t={37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",33:"PageUp",34:"PageDown",36:"Home",35:"End"};return t[e.keyCode]||""}/**
 * Whether a key should be handled exclusively by a quiz interaction control.
 *
 * @param {string} key Normalized key from normalizeKey().
 * @return {boolean}
 */function v(e){return e==="ArrowLeft"||e==="ArrowRight"||e==="ArrowUp"||e==="ArrowDown"||e==="PageUp"||e==="PageDown"||e==="Home"||e==="End"}/**
 * Resolve the next slider value from a keyboard step key.
 *
 * @param {number} currentValue Current slider value.
 * @param {string} key          Normalized key.
 * @param {{ step: number, largeStep?: number, min: number, max: number }} options Step config.
 * @return {number|null} Next value, or null when the key is not handled.
 */function l(e,t,r){var n=typeof r.step==="number"&&r.step>0?r.step:1;var i=typeof r.largeStep==="number"&&r.largeStep>0?r.largeStep:n*10;var a=typeof r.min==="number"?r.min:0;var o=typeof r.max==="number"?r.max:100;if(t==="ArrowRight"||t==="ArrowUp"){return e+n}if(t==="ArrowLeft"||t==="ArrowDown"){return e-n}if(t==="PageUp"){return e+i}if(t==="PageDown"){return e-i}if(t==="Home"){return a}if(t==="End"){return o}return null}/**
 * Whether a key moves a grid cursor.
 *
 * @param {string} key Normalized key.
 * @return {boolean}
 */function s(e){return e==="ArrowLeft"||e==="ArrowRight"||e==="ArrowUp"||e==="ArrowDown"}/**
 * Move an integer grid cursor by one unit using arrow keys.
 *
 * @param {{ x: number, y: number }} cursor Current cursor position.
 * @param {string}                    key    Normalized key.
 * @param {{ min: number, max: number }} bounds Axis bounds.
 * @return {{ x: number, y: number }|null} Updated cursor or null when key is not handled.
 */function c(e,t,r){if(!e||!r){return null}var n=r.min;var i=r.max;var a=e.x;var o=e.y;if(t==="ArrowLeft"){a-=1}else if(t==="ArrowRight"){a+=1}else if(t==="ArrowUp"){o+=1}else if(t==="ArrowDown"){o-=1}else{return null}a=Math.max(n,Math.min(i,a));o=Math.max(n,Math.min(i,o));return{x:a,y:o}}/**
 * Move a normalized (0–1) cursor using arrow keys.
 *
 * @param {{ x: number, y: number }} cursor Current position.
 * @param {string}                    key    Normalized key.
 * @param {{ step?: number, largeStep?: number, shiftKey?: boolean }} options Step config.
 * @return {{ x: number, y: number }|null}
 */function p(e,t,r){if(!e||!s(t)){return null}var n=r||{};var i=typeof n.step==="number"&&n.step>0?n.step:.01;var a=typeof n.largeStep==="number"&&n.largeStep>0?n.largeStep:.05;var o=n.shiftKey?a:i;var u=e.x;var f=e.y;if(t==="ArrowLeft"){u-=o}else if(t==="ArrowRight"){u+=o}else if(t==="ArrowUp"){f-=o}else if(t==="ArrowDown"){f+=o}else{return null}u=Math.max(0,Math.min(1,u));f=Math.max(0,Math.min(1,f));return{x:u,y:f}}/**
 * Move a pixel cursor within canvas bounds using arrow keys.
 *
 * @param {{ x: number, y: number }} cursor Current position.
 * @param {string}                    key    Normalized key.
 * @param {{ width: number, height: number }} bounds Canvas size in pixels.
 * @param {{ step?: number, largeStep?: number, shiftKey?: boolean }} options Step config.
 * @return {{ x: number, y: number }|null}
 */function d(e,t,r,n){if(!e||!r||!s(t)){return null}var i=n||{};var a=typeof i.step==="number"&&i.step>0?i.step:5;var o=typeof i.largeStep==="number"&&i.largeStep>0?i.largeStep:20;var u=i.shiftKey?o:a;var f=Math.max(0,r.width);var v=Math.max(0,r.height);var l=e.x;var c=e.y;if(t==="ArrowLeft"){l-=u}else if(t==="ArrowRight"){l+=u}else if(t==="ArrowUp"){c-=u}else if(t==="ArrowDown"){c+=u}else{return null}l=Math.max(0,Math.min(f,l));c=Math.max(0,Math.min(v,c));return{x:l,y:c}}/**
 * Format normalized pin coordinates for screen-reader announcements.
 *
 * @param {number} x Horizontal position (0–1).
 * @param {number} y Vertical position (0–1).
 * @return {string}
 */function m(e,t){var r=Math.max(0,Math.min(1,typeof e==="number"?e:parseFloat(e,10)||0));var n=Math.max(0,Math.min(1,typeof t==="number"?t:parseFloat(t,10)||0));return r.toFixed(2)+", "+n.toFixed(2)};// CONCATENATED MODULE: ./assets/src/js/quiz-type/pin-image-question.js
/**
 * Frontend behaviour for "Pin on Image" quiz questions (Tutor Pro).
 *
 * Finds all `.tutor-pin-image-question` wrappers rendered by
 * `tutor-pro/templates/learning-area/quiz/questions/pin-image.php` and wires click-to-place-pin:
 * normalized (x, y) in 0–1 are written to hidden inputs [answers][pin][x] and [y].
 *
 * @package TutorPro
 * @since 4.0.0
 */var w=".tutor-pin-image-question";var g=".tutor-pin-image-wrapper";var y=".tutor-pin-image-placement";var h=".tutor-pin-image-marker";var L='input[id^="tutor-pin-image-x-"]';var x='input[id^="tutor-pin-image-y-"]';var E=".tutor-quiz-a11y-live-region";var A="tutor-pin-image-wrapper-has-pin";var b="tutor-pin-image-wrapper-aiming";var M="tutor-pin-image-placement-preview";var S="tutor-pin-image-placement-dropping";var D="tutor-pin-image-placement-dropping-from-aim";var q="_tutorPinImageTeardown";var P=(()=>{var e=new Set;var t=false;function r(t){e.forEach(e=>e.handleMove(t))}function n(t){e.forEach(e=>e.handleEnd(t))}function i(){if(t){return}window.addEventListener("pointermove",r);window.addEventListener("pointerup",n);window.addEventListener("pointercancel",n);t=true}function a(){if(!t||e.size>0){return}window.removeEventListener("pointermove",r);window.removeEventListener("pointerup",n);window.removeEventListener("pointercancel",n);t=false}return{register(t){e.add(t);i()},unregister(t){e.delete(t);a()}}})();function k(e){return Math.max(0,Math.min(1,typeof e==="number"?e:parseFloat(e,10)||0))}function C(e){return e&&e.classList.contains(A)}function R(){return typeof window.matchMedia==="function"&&window.matchMedia("(prefers-reduced-motion: reduce)").matches}function U(e){if(!e){return}if(typeof e[q]==="function"){e[q]()}var t=e.querySelector(g);var r=e.querySelector(y);var n=e.querySelector(h);var i=e.querySelector(L);var a=e.querySelector(x);var v=e.querySelector(E);var l=r||n;if(!t||!i||!a){return}var c={x:.5,y:.5};var d=false;var w=false;var U=false;function B(e){o(v,e)}function I(){if(r){r.classList.remove(S,D)}}function F(e){if(!r||R()){return}r.classList.remove(S,D);void r.offsetWidth;if(e){r.classList.add(D)}r.classList.add(S)}function X(e){if(!t){return}if(e){t.classList.add(b)}else{t.classList.remove(b)}}function Y(e,r){var n=t.getBoundingClientRect();var i=n.width;var a=n.height;if(!i||!a){return null}return{x:k((e-n.left)/i),y:k((r-n.top)/a)}}function z(e,r){if(C(t)||U){return}X(true);K(e,r,{preview:true})}function K(e,t,r){var n=r||{};if(!l){return}l.style.left=e*100+"%";l.style.top=t*100+"%";l.style.display="block";var i=Boolean(n.drop)&&l.classList.contains(M);if(n.preview){l.classList.add(M)}else{l.classList.remove(M)}if(n.drop){F(i)}else{I()}}function H(){if(!l){return}l.style.display="none";l.classList.remove(M);I();X(false)}function T(e,r,n){var o=t.getBoundingClientRect();var u=o.width;var f=o.height;if(!u||!f){return}var v=(e-o.left)/u;var l=(r-o.top)/f;v=k(v);l=k(l);var s=n||{};var p=!C(t)&&!s.preview;i.value=String(v);a.value=String(l);i.dispatchEvent(new Event("input",{bubbles:true}));a.dispatchEvent(new Event("input",{bubbles:true}));K(v,l,Object.assign({},s,{drop:p}));t.classList.add(A);X(false);c={x:v,y:l}}function j(e,r,n){var i=t.getBoundingClientRect();var a=i.width;var o=i.height;if(!a||!o){return}var u=k(e);var f=k(r);T(i.left+u*a,i.top+f*o,n)}function O(){i.value="";a.value="";i.dispatchEvent(new Event("input",{bubbles:true}));a.dispatchEvent(new Event("input",{bubbles:true}));t.classList.remove(A);H();c={x:.5,y:.5}}function _(){if(C(t)){return}K(c.x,c.y,{preview:true})}function N(){if(C(t)){if(l){l.classList.remove(M)}return}H()}function W(e,t,r){var n=r?r+" ":"";B(n+m(e,t)+".")}function G(){var e=t.getBoundingClientRect();var r=k(i.value);var n=k(a.value);return{x:e.left+r*e.width,y:e.top+n*e.height}}var J=null;var Q=0;var V=0;var Z=false;function $(){U=false;J=null;Q=0;V=0;window.setTimeout(function(){Z=false},0)}function ee(e){if(!U||e.pointerId!==J){return}e.preventDefault();Z=true;T(e.clientX-Q,e.clientY-V)}function et(e){if(!U||e.pointerId!==J){return}e.preventDefault();T(e.clientX-Q,e.clientY-V);$()}function er(){w=true;d=false}function en(e){if(C(t)||U||e.pointerType==="touch"){return}var r=Y(e.clientX,e.clientY);if(!r){return}c=r;z(r.x,r.y)}function ei(){if(C(t)||d){return}H()}function ea(e){if(Z){e.preventDefault();return}e.preventDefault();T(e.clientX,e.clientY);W(k(i.value),k(a.value),"Pin placed at")}function eo(){var r=e.getAttribute("data-question-id")||"";var n=r?"tutor-pin-image-instruction-"+r:"";var o=v?v.id:"";u(t,[n,o].filter(Boolean));if(w){w=false;return}d=true;if(C(t)){c={x:k(i.value),y:k(a.value)};K(c.x,c.y)}else{_()}}function eu(){d=false;N()}function ef(e){var r=f(e);if(r==="Enter"){e.preventDefault();j(c.x,c.y);W(c.x,c.y,"Pin placed at");return}if(r==="c"||r==="C"){if(!C(t)){return}e.preventDefault();O();B("Pin cleared.");if(d){_()}return}if(!s(r)){return}e.preventDefault();if(C(t)){c={x:k(i.value),y:k(a.value)}}var n=p(c,r,{shiftKey:e.shiftKey});if(!n){return}c=n;if(C(t)){j(c.x,c.y);W(c.x,c.y,"Pin moved to");return}_();W(c.x,c.y,"Position")}function ev(){t.removeEventListener("mousedown",er);t.removeEventListener("pointermove",en);t.removeEventListener("pointerleave",ei);t.removeEventListener("click",ea);t.removeEventListener("focus",eo);t.removeEventListener("blur",eu);t.removeEventListener("keydown",ef)}t.addEventListener("mousedown",er);t.addEventListener("pointermove",en);t.addEventListener("pointerleave",ei);t.addEventListener("click",ea);t.addEventListener("focus",eo);t.addEventListener("blur",eu);t.addEventListener("keydown",ef);if(!n){e[q]=function(){ev();delete e[q]};return}function el(e){if(!r||e.target!==n){return}I()}function es(e){// Drag should only be possible after first placement.
if(!C(t)){return}e.preventDefault();I();var r=G();U=true;J=e.pointerId;Q=e.clientX-r.x;V=e.clientY-r.y;Z=false}var ec=n.querySelector(".tutor-pin-image-handle")||n;n.addEventListener("animationend",el);ec.addEventListener("pointerdown",es);var ep={handleMove:ee,handleEnd:et};P.register(ep);e[q]=function(){ev();ec.removeEventListener("pointerdown",es);n.removeEventListener("animationend",el);P.unregister(ep);delete e[q]}}function B(){var e=document.querySelectorAll(w);if(!e||!e.length){return}for(var t=0;t<e.length;t++){U(e[t])}}// Course-builder iframe preview re-init (see Tutor core PinImagePreview.tsx).
window._tutorPinImageInitAll=function(){B()};if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",B)}else{B()}})();