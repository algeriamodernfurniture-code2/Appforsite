<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;
// Preserve ads and analytics by default. Admin can remove them manually from the database if needed.
delete_option( 'ostudy_ads_settings' );
