OStudy Tutor LMS Ads 1.5.4

1.5.4: Adds a visible "Ad" sticker/badge to every ad unit (banner, sidebar, HTML and popup) so sponsored content is clearly distinguishable from real page content at a glance, in addition to the existing aria-label="Advertisement" for screen readers. Purely decorative and non-interactive (pointer-events disabled, aria-hidden), styled via .ostudy-ad__badge in ostudy-ads.css.

OStudy Tutor LMS Ads 1.4.7

Placement stability update:
- Automatic ads are staged early in wp_footer, before footer scripts, then moved into semantic page containers by JavaScript.
- This prevents top banners from appearing underneath the entire page due to theme/Tutor hook differences.
- Default instructor search remains /tutors.
- Admin > OStudy Ads > Settings includes editable CSS target selectors for every automatic placement.
- Popups remain viewport-fixed and are never inserted into page content.
- Dashboard and Focus Mode side ads are inserted inside their sidebar containers and use sticky positioning on desktop.
- No Tutor LMS core files or existing course-sponsorship data are modified.


1.3.0: Adds a dedicated instructor public-profile desktop side-ad rail. By default it uses the left empty margin, aligned to the profile content wrapper, and hides automatically when the viewport has insufficient side space.


SHORTCODES / MANUAL PLACEMENT

You can place an ad directly inside any editable WordPress page, homepage section, Gutenberg/Elementor block, or other shortcode area. This is recommended when automatic placement is not precise enough for a particular design.

1. Show a specific ad by ID:
[ostudy_ad id=123]
Replace 123 with the ad ID shown in OStudy Ads > All Ads.

2. Show a specific ad using a placement style:
[ostudy_ad id=123 zone=home_top]
The ad is still inserted exactly where the shortcode is placed; the zone controls styling/placement class only.

3. Let the system choose an eligible ad for a zone:
[ostudy_ad zone=home_top]
Examples: home_top, course_search_top, tutor_search_top, instructor_profile_top, course_page_top, dashboard_sidebar, focus_mode_top.

4. Respect page-target selection when using an explicit ID:
[ostudy_ad id=123 zone=home_top respect_page_target=1]
Default is 0 because a manually inserted shortcode already identifies the page/location. Status, date/time, device, role, category, and frequency limits are always still checked.

Useful page-builder examples:
- Homepage: add [ostudy_ad id=123] exactly between your chosen home sections.
- Custom landing page: add [ostudy_ad id=123] exactly where the banner should appear.
- Course/instructor custom content: add the shortcode inside the desired content block rather than relying on automatic selectors.
- Popup: use an ad whose Type is Popup; the shortcode will still render it as a viewport popup.

IMPORTANT: Do not edit Tutor LMS core files. Shortcodes are intentionally independent of the existing course sponsorship system.

1.4.7 fixes:
- Staging markup now renders before wp_print_footer_scripts so the mounting script cannot run before the ads exist.
- Tutor LMS 4.0.8 course archive, public profile, dashboard and course selectors are more specific.
- Instructor profile top ads are inserted inside Tutor's second profile container before the sidebar/content floats.
- Instructor profile side ads stay inside Tutor's real .tutor-user-profile-sidebar column and no longer use sticky positioning that conflicts with Tutor's overflow container.
- Removed unsafe generic main/body fallback mounting; missing specialized targets are retried rather than inserted in the wrong place.
- Added robust handling for relative/protocol-relative/media-library image URLs and bare URLs entered in Custom HTML.
- Added a client-side image fallback and TranslatePress data-no-translation/data-no-dynamic-translation protection for ad media/moved ad nodes.

1.5.1 adds per-ad custom padding (top/right/bottom/left, 0-500px) and hardens Custom HTML image URL rendering.

1.5.1 additions: course Wilaya targeting reads _tlms_ipe_wilaya from the course author; popup close lock/countdown; Start/End dates are shown on All Ads.
