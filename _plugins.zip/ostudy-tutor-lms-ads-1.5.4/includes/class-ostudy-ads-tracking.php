<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class OStudy_Ads_Tracking {
    private static $instance;
    public static function instance() {
        if ( ! self::$instance ) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_action( 'wp_ajax_ostudy_ads_track', array( $this, 'ajax_track' ) );
        add_action( 'wp_ajax_nopriv_ostudy_ads_track', array( $this, 'ajax_track' ) );
    }

    public function ajax_track() {
        check_ajax_referer( 'ostudy_ads_track', 'nonce' );
        $ad_id = absint( $_POST['ad_id'] ?? 0 );
        $type = sanitize_key( $_POST['type'] ?? '' );
        $placement = sanitize_key( $_POST['placement'] ?? '' );
        if ( ! $ad_id || ! in_array( $type, array( 'impression', 'click' ), true ) ) wp_send_json_error();
        global $wpdb;
        $hash_source = wp_get_session_token();
        if ( ! $hash_source ) $hash_source = wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' ) . '|' . wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' );
        $hash = hash_hmac( 'sha256', (string) $hash_source, wp_salt( 'auth' ) );

        // Guard against duplicate/rapid-fire events for the same visitor+ad+event
        // type (retry storms, the JS's own delayed re-scan passes, or a scripted
        // flood) inflating impression/click counts and any impression-based cap.
        $dedup_key = 'ostudy_ads_evt_' . substr( $hash, 0, 20 ) . '_' . $ad_id . '_' . $type;
        $dedup_window = ( 'impression' === $type ) ? 60 : 5;
        if ( false !== get_transient( $dedup_key ) ) {
            wp_send_json_success( array( 'deduped' => true ) );
        }
        set_transient( $dedup_key, 1, $dedup_window );

        // Coarse per-visitor rate cap across all ads/events, independent of the
        // per-event dedup above, to blunt a flood that varies ad_id/type to dodge it.
        $rate_key = 'ostudy_ads_rate_' . substr( $hash, 0, 20 );
        $rate_count = (int) get_transient( $rate_key );
        if ( $rate_count >= 60 ) {
            wp_send_json_error( array( 'rate_limited' => true ) );
        }
        set_transient( $rate_key, $rate_count + 1, 60 );

        $wpdb->insert( OStudy_Ads_DB::stats_table(), array(
            'ad_id' => $ad_id,
            'stat_type' => $type,
            'user_hash' => $hash,
            'placement' => $placement,
            'device' => OStudy_Ads_Utils::current_device(),
            'created_at' => current_time( 'mysql' ),
        ), array( '%d', '%s', '%s', '%s', '%s', '%s' ) );
        wp_send_json_success();
    }
}
