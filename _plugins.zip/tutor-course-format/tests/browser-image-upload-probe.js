/*
 * Browser probe: log into the test site as an instructor, open the Tutor
 * LMS course builder, and capture the actual request Tutor sends when
 * uploading a course featured image and (separately) an instructor profile
 * photo — whichever endpoint/field names/action values it really uses.
 *
 * This exists because TCF_Plugin::detect_instructor_image_context() (in
 * includes/class-tcf-plugin.php) currently GUESSES the upload context by
 * substring-matching $_REQUEST['action']/['field']/['name'] against marker
 * words like 'thumbnail', 'featured', 'avatar', 'profile_photo'. That guess
 * has never been checked against a real Tutor LMS install (unlike every
 * other integration point in this plugin, which is documented as verified
 * against a specific shipped bundle). Run this against a staging site with
 * Tutor LMS installed, compare the captured request(s) below against the
 * marker lists in detect_instructor_image_context(), and either:
 *
 *   - adjust the marker lists directly, or
 *   - hardcode the correct context via the 'tcf_instructor_image_upload_context'
 *     filter added alongside this probe (see class-tcf-plugin.php).
 *
 * Usage: node tests/browser-image-upload-probe.js <course_id>
 *   TCF_USER / TCF_PASS   instructor account to log in as (defaults below)
 *   TCF_IMAGE             path to a small local image file to upload
 *                         (defaults to a 1x1 PNG generated on the fly)
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const puppeteer = require('/tmp/browsertest/node_modules/puppeteer-core');

const BASE = 'http://localhost:8899';
const COURSE_ID = process.argv[2] || '8';
const USER = process.env.TCF_USER || 'instructor';
const PASS = process.env.TCF_PASS || 'instructor';

// A minimal valid 1x1 transparent PNG, used if TCF_IMAGE isn't given.
const TINY_PNG_BASE64 =
	'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';

function resolveImagePath() {
	if (process.env.TCF_IMAGE) {
		return process.env.TCF_IMAGE;
	}
	const p = path.join(os.tmpdir(), 'tcf-probe.png');
	fs.writeFileSync(p, Buffer.from(TINY_PNG_BASE64, 'base64'));
	return p;
}

(async () => {
	const browser = await puppeteer.launch({
		executablePath: '/usr/bin/chromium',
		headless: 'new',
		args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
	});
	const page = await browser.newPage();
	await page.setViewport({ width: 1600, height: 1200 });

	const logs = [];
	page.on('console', (m) => logs.push(`[${m.type()}] ${m.text()}`));
	page.on('pageerror', (e) => logs.push(`[pageerror] ${e.message}`));

	// Capture every upload-shaped request: classic multipart to
	// async-upload.php/admin-ajax.php, and REST createItem POSTs to
	// /wp/v2/media (which is what a raw-binary sideload upload looks like
	// on the wire — see the wp_handle_sideload_prefilter fix in
	// class-tcf-plugin.php).
	const uploads = [];
	page.on('request', (req) => {
		const u = req.url();
		const method = req.method();
		const isUploadish =
			method === 'POST' &&
			(u.includes('async-upload.php') || u.includes('admin-ajax.php') || u.includes('/wp/v2/media') || u.includes('/wp-json/'));
		if (!isUploadish) {
			return;
		}
		const headers = req.headers();
		const contentType = headers['content-type'] || '';
		const isBinary = contentType && !contentType.includes('multipart/form-data') && !contentType.includes('application/x-www-form-urlencoded');
		uploads.push({
			url: u,
			contentType,
			bodyKind: isBinary ? 'raw-binary (wp_handle_sideload path)' : 'form-encoded (wp_handle_upload path)',
			postDataPreview: isBinary ? '<binary, not printed>' : (req.postData() || '').slice(0, 2000),
			headers,
		});
	});

	// ---- log in -------------------------------------------------------
	await page.goto(`${BASE}/wp-login.php`, { waitUntil: 'networkidle2' });
	await page.type('#user_login', USER);
	await page.type('#user_pass', PASS);
	await Promise.all([
		page.waitForNavigation({ waitUntil: 'networkidle2' }),
		page.click('#wp-submit'),
	]);

	// ---- course builder: upload the featured image ---------------------
	await page.goto(`${BASE}/wp-admin/admin.php?page=create-course&course_id=${COURSE_ID}`, {
		waitUntil: 'networkidle2',
		timeout: 90000,
	});
	await new Promise((r) => setTimeout(r, 12000));

	console.log('=== Looking for a featured-image upload control ===');
	const fileInputs = await page.$$('input[type="file"]');
	console.log(`found ${fileInputs.length} <input type="file"> on the course builder page`);

	if (fileInputs.length) {
		await fileInputs[0].uploadFile(resolveImagePath());
		await new Promise((r) => setTimeout(r, 6000));
	} else {
		console.log('No direct file input found — the featured image picker likely opens the wp.media modal.');
		console.log('Open it manually in a headed run and re-check network traffic, or add a click-through here.');
	}

	console.log('=== UPLOAD REQUESTS CAPTURED SO FAR:', uploads.length, '===');
	uploads.forEach((u, i) => {
		console.log(`#${i} ${u.url}`);
		console.log('   content-type:', u.contentType);
		console.log('   body kind:', u.bodyKind);
		console.log('   body preview:', u.postDataPreview);
	});

	console.log('=== CONSOLE (last 25) ===');
	console.log(logs.slice(-25).join('\n'));

	await browser.close();
})().catch((e) => {
	console.error('FATAL', e);
	process.exit(1);
});
