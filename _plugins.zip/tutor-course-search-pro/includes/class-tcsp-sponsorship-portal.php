<?php
/**
 * Front-end sponsorship portal and sponsorship order tracker.
 *
 * @package Tutor_Course_Search_Pro
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class TCSP_Sponsorship_Portal {
    const CPT = 'tcsp_sponsor_order';
    const NONCE = 'tcsp_sponsor_portal';
    const PAGE_SLUG = 'sponsorship';

    private $settings;

    public function __construct( TCSP_Settings $settings ) { $this->settings = $settings; }

    public function register() {
        add_action( 'init', array( $this, 'register_cpt' ), 5 );
        add_action( 'init', array( $this, 'maybe_create_page' ), 31 );
        add_action( 'init', array( $this, 'ensure_sponsorship_checkout_products' ), 32 );
        add_shortcode( 'tcsp_sponsorship_portal', array( $this, 'shortcode' ) );
        add_action( 'admin_init', array( $this, 'admin_actions' ) );
        add_action( 'admin_init', array( $this, 'maybe_create_page_admin' ) );
        add_action( 'template_redirect', array( $this, 'handle_frontend_action' ) );
        add_action( 'template_redirect', array( $this, 'reconcile_native_orders' ), 1 );
        add_action( 'wp_footer', array( $this, 'cleanup_checkout_course_after_payment' ) );
        add_action( 'tcsp_process_scheduled_sponsorships', array( $this, 'process_scheduled_sponsorships' ) );
        if ( ! wp_next_scheduled( 'tcsp_process_scheduled_sponsorships' ) ) {
            wp_schedule_event( time() + 300, 'hourly', 'tcsp_process_scheduled_sponsorships' );
        }
        add_filter( 'load_dashboard_template_part_from_other_location', array( $this, 'dashboard_template_location' ), 20, 1 );
        add_filter( 'tutor_checkout_item_name', array( $this, 'checkout_item_name' ), 10, 2 );
        add_filter( 'tioc_course_payee_id', array( $this, 'offline_payee_for_sponsorship' ), 10, 2 );
        add_action( 'pre_get_posts', array( $this, 'exclude_checkout_products_from_public_queries' ), 20 );
        // Tutor instructor public profiles often build their course list with a
        // secondary WP_Query after pre_get_posts has already run. Enforce the
        // exclusion again at SQL level so internal sponsorship checkout courses
        // can never leak into public profile course lists.
        add_filter( 'posts_clauses', array( $this, 'exclude_checkout_products_from_public_course_sql' ), 99999, 2 );
        add_filter( 'the_posts', array( $this, 'remove_checkout_products_from_public_course_results' ), PHP_INT_MAX, 2 );
        add_filter( 'tutor_dashboard/instructor_nav_items', array( $this, 'dashboard_nav' ) );
        add_action( 'wp_head', array( $this, 'print_dashboard_nav_icon_style' ) );
    }

    public function register_cpt() {
        register_post_type( self::CPT, array(
            'labels' => array( 'name' => 'Sponsorship Orders', 'singular_name' => 'Sponsorship Order' ),
            'public' => false, 'show_ui' => false, 'supports' => array( 'title' ),
            'capability_type' => 'post', 'map_meta_cap' => true,
        ) );
    }

    public function maybe_create_page() {
        if ( is_admin() ) return;
        $this->ensure_frontend_pages();
    }

    public function maybe_create_page_admin() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $this->ensure_frontend_pages();
    }

    private function ensure_frontend_pages() {
        $pages = array();
        if ( $this->settings->get( 'enable_tutor_search' ) ) {
            $slug = sanitize_title( $this->settings->get( 'tutor_page_slug' ) ?: 'tutors' );
            $pages[] = array( 'slug' => $slug, 'title' => __( 'Tutors', 'tutor-course-search-pro' ), 'content' => '[tcsp_tutor_search]' );
        }
        foreach ( $pages as $page ) {
            $existing = get_page_by_path( $page['slug'], OBJECT, 'page' );
            if ( $existing ) {
                $content = (string) get_post_field( 'post_content', $existing->ID );
                if ( false === strpos( $content, '[' ) ) {
                    wp_update_post( array( 'ID' => $existing->ID, 'post_content' => $page['content'] ) );
                }
                continue;
            }
            wp_insert_post( array( 'post_title' => $page['title'], 'post_name' => $page['slug'], 'post_content' => $page['content'], 'post_status' => 'publish', 'post_type' => 'page' ) );
        }
    }

    public function dashboard_nav( $links ) {
        if ( ! is_user_logged_in() ) return $links;
        // Use a verified Tutor icon font class directly (full class name, not a slug
        // that needs a "tutor-icon-" prefix appended). "offer" renders a badge/promo
        // glyph that fits sponsorship/promotion well and exists across Tutor LMS
        // versions, unlike the previous TUTOR\Icon::ANNOUNCEMENT lookup which either
        // silently fell back or produced a double-prefixed, non-existent class.
        $icon = apply_filters( 'tcsp_sponsorship_dashboard_nav_icon', 'tutor-icon-speaker' );
        $links['tcsp-sponsorship'] = array(
            'title' => __( 'Sponsorship', 'tutor-course-search-pro' ),
            'url'   => function_exists( 'tutor_utils' ) ? tutor_utils()->tutor_dashboard_url( 'tcsp-sponsorship' ) : home_url( '/' . self::PAGE_SLUG . '/' ),
            'icon'  => $icon,
            'auth_cap' => tutor()->instructor_role,
        );
        return $links;
    }

    /**
     * Whether Tutor LMS renders an 'icon' font class, an SVG-based icon
     * component, or nothing at all for a filter-added nav item differs by
     * version and can't be relied on. To guarantee the icon actually shows,
     * inject a small CSS rule that draws it via ::before on the dashboard
     * nav link itself, independent of how Tutor renders the menu markup.
     * The href always contains "tcsp-sponsorship" (the dashboard sub-page
     * slug), so this only targets our own nav item.
     */
    public function print_dashboard_nav_icon_style() {
        if ( ! is_user_logged_in() ) return;
        // Megaphone/announcement glyph — matches the dashicons-megaphone icon
        // already used for the wp-admin "Sponsorship" menu, and reads clearly
        // as promotion/sponsorship rather than a generic star. Built as plain
        // straight-line shapes (no arcs) so the inline SVG is guaranteed valid,
        // and rendered as a background-image (not a mask) so it's not at the
        // mercy of browser differences in mask alpha/luminance handling.
        $svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23555d66'>"
            . "<path d='M3 9v6h3l7 5V4L6 9H3z'/>"
            . "<rect x='1' y='10' width='2' height='4' rx='1'/>"
            . "<circle cx='18' cy='12' r='1.4'/>"
            . "<circle cx='20.6' cy='12' r='1'/>"
            . "</svg>";
        $data_uri = 'data:image/svg+xml,' . rawurlencode( $svg );
        ?>
        <style>
        a[href*="tcsp-sponsorship"]::before{content:"";display:inline-block;width:16px;height:16px;margin-right:8px;vertical-align:-3px;background:no-repeat center/contain url("<?php echo esc_attr( $data_uri ); ?>");}
        </style>
        <?php
    }

    public function dashboard_template_location( $path ) {
        if ( ! function_exists( 'tutor_utils' ) || ! is_user_logged_in() ) return $path;
        global $wp_query;
        $page = isset( $wp_query->query_vars['tutor_dashboard_page'] ) ? sanitize_key( $wp_query->query_vars['tutor_dashboard_page'] ) : '';
        if ( 'tcsp-sponsorship' !== $page || ! $this->user_is_instructor( get_current_user_id() ) ) return $path;
        return plugin_dir_path( dirname( __FILE__ ) ) . 'templates/dashboard/tcsp-sponsorship.php';
    }

    public function render_dashboard_template() {
        echo $this->render_portal_view();
    }

    private function user_is_instructor( $user_id ) {
        $u = get_userdata( $user_id );
        if ( ! $u ) return false;
        return in_array( 'tutor_instructor', (array) $u->roles, true ) || in_array( 'administrator', (array) $u->roles, true );
    }

    private function own_courses( $user_id ) {
        global $wpdb;
        $course_pt = TCSP_Plugin::COURSE_CPT;
        // Show the tutor's real published courses, including courses linked through Tutor LMS
        // multi-instructor assignments. Only hide internal checkout/temp courses generated by
        // Tutor Course Search Pro and the supplied Private Sessions plugin.
        $ids = get_posts( array(
            'post_type' => $course_pt,
            'post_status' => 'publish',
            'author' => absint( $user_id ),
            'posts_per_page' => -1,
            'fields' => 'ids',
            'orderby' => 'title',
            'order' => 'ASC',
        ) );
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT CAST(um.meta_value AS UNSIGNED)
             FROM {$wpdb->usermeta} um
             INNER JOIN {$wpdb->posts} p
               ON p.ID=CAST(um.meta_value AS UNSIGNED)
              AND p.post_type=%s
              AND p.post_status='publish'
             WHERE um.user_id=%d
               AND um.meta_key='_tutor_instructor_course_id'",
            $course_pt,
            absint( $user_id )
        ) );
        $ids = array_values( array_unique( array_merge( array_map( 'absint', (array) $ids ), array_map( 'absint', (array) $rows ) ) ) );
        $out = array();
        foreach ( $ids as $id ) {
            if ( $id <= 0 || $course_pt !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) continue;
            // TCSP sponsorship checkout products.
            if ( '1' === (string) get_post_meta( $id, '_tcsp_sponsorship_checkout_product', true ) ) continue;
            // Temporary/private-session courses created by the supplied Private Sessions plugin.
            if ( '1' === (string) get_post_meta( $id, '_tlms_ps_internal_course', true ) ) continue;
            if ( '1' === (string) get_post_meta( $id, '_tlms_ps_rating_course', true ) ) continue;
            $title = get_the_title( $id );
            if ( $title ) $out[ $id ] = $title;
        }
        asort( $out, SORT_NATURAL | SORT_FLAG_CASE );
        return $out;
    }

    private function order_meta( $id, $key, $default = '' ) { $v = get_post_meta( $id, $key, true ); return '' !== $v ? $v : $default; }

    private function orders( $user_id ) {
        $q = new WP_Query( array( 'post_type' => self::CPT, 'post_status' => 'private', 'posts_per_page' => 100, 'author' => $user_id, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) );
        return $q->posts;
    }

    private function has_open_sponsorship( $user_id, $target_type, $target_id ) {
        $existing = get_posts( array(
            'post_type' => self::CPT,
            'post_status' => 'private',
            'author' => absint( $user_id ),
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => array(
                array( 'key' => '_tcsp_target_type', 'value' => $target_type ),
                array( 'key' => '_tcsp_target_id', 'value' => absint( $target_id ) ),
                array( 'key' => '_tcsp_status', 'value' => array( 'pending', 'paid', 'scheduled' ), 'compare' => 'IN' ),
            ),
            'no_found_rows' => true,
        ) );
        return ! empty( $existing );
    }

    private function plan_locked( $user_id, $target_type, $target_id, $tier ) {
        // Short-lived lock prevents rapid double-submit/race creation.
        $lock_key = 'tcsp_sp_lock_' . md5( absint( $user_id ) . '|' . $target_type . '|' . absint( $target_id ) );
        if ( get_transient( $lock_key ) ) return true;
        set_transient( $lock_key, sanitize_key( $tier ), 15 );
        return false;
    }

    private function plan_label( $type, $tier ) {
        $tiers = 'tutor' === $type ? $this->settings->tutor_promotion_tiers() : $this->settings->promotion_tiers();
        return isset( $tiers[ $tier ]['label'] ) ? $tiers[ $tier ]['label'] : $tier;
    }

    private function plan( $type, $tier ) {
        $tiers = 'tutor' === $type ? $this->settings->tutor_promotion_tiers() : $this->settings->promotion_tiers();
        return isset( $tiers[ $tier ] ) ? $tiers[ $tier ] : null;
    }

    private function max_units() {
        return min( 12, max( 1, absint( $this->settings->get( 'sponsorship_max_units' ) ?: 12 ) ) );
    }

    private function normalize_units( $units ) {
        return min( $this->max_units(), max( 1, absint( $units ) ) );
    }

    private function allowed_unit_options() {
        $max = $this->max_units();
        $options = array( 1, 3, 6, 12 );
        $options = array_values( array_filter( $options, function( $n ) use ( $max ) { return $n <= $max; } ) );
        if ( ! in_array( $max, $options, true ) ) $options[] = $max;
        return array_values( array_unique( $options ) );
    }

    private function unit_discount_pct( $plan, $units ) {
        $units = $this->normalize_units( $units );
        if ( $units >= 12 ) return min( 100, max( 0, (float) ( $plan['discount_12'] ?? 0 ) ) );
        if ( $units >= 6 ) return min( 100, max( 0, (float) ( $plan['discount_6'] ?? 0 ) ) );
        if ( $units >= 3 ) return min( 100, max( 0, (float) ( $plan['discount_3'] ?? 0 ) ) );
        return 0;
    }

    private function purchase_totals( $plan, $units ) {
        $units = $this->normalize_units( $units );
        $base = max( 0, (float) ( $plan['price'] ?? 0 ) );
        $discount_pct = $this->unit_discount_pct( $plan, $units );
        $amount = round( $base * $units * ( 1 - ( $discount_pct / 100 ) ), 2 );
        $duration = max( 1, (int) ( $plan['duration'] ?? 1 ) ) * $units;
        return array( 'units' => $units, 'unit_price' => $base, 'discount_pct' => $discount_pct, 'amount' => $amount, 'duration' => $duration );
    }

    private function duration_unit_text( $days, $plural = true ) {
        $days = max( 1, absint( $days ) );
        if ( 1 === $days ) return $plural ? __( 'day', 'tutor-course-search-pro' ) : __( 'day', 'tutor-course-search-pro' );
        if ( 7 === $days ) return $plural ? __( 'week', 'tutor-course-search-pro' ) : __( 'week', 'tutor-course-search-pro' );
        if ( 30 === $days ) return $plural ? __( 'month', 'tutor-course-search-pro' ) : __( 'month', 'tutor-course-search-pro' );
        if ( 365 === $days ) return $plural ? __( 'year', 'tutor-course-search-pro' ) : __( 'year', 'tutor-course-search-pro' );
        if ( 0 === $days % 7 ) {
            $weeks = intdiv( $days, 7 );
            return sprintf( _n( '%d week', '%d weeks', $weeks, 'tutor-course-search-pro' ), $weeks );
        }
        return $days . ' ' . __( 'days', 'tutor-course-search-pro' );
    }

    private function purchase_label( $plan, $units ) {
        $totals = $this->purchase_totals( $plan, $units );
        $base_days = max( 1, (int) ( $plan['duration'] ?? 1 ) );
        if ( in_array( $base_days, array( 1, 7, 30, 365 ), true ) ) {
            $unit_name = $this->duration_unit_text( $base_days, true );
            $label = sprintf( _n( '%d %s', '%d %s', $totals['units'], 'tutor-course-search-pro' ), $totals['units'], $unit_name );
        } elseif ( 0 === $base_days % 7 ) {
            $label = $totals['units'] . ' × ' . intdiv( $base_days, 7 ) . ' ' . __( 'weeks', 'tutor-course-search-pro' );
        } else {
            $label = $totals['units'] . ' × ' . $base_days . ' ' . __( 'days', 'tutor-course-search-pro' );
        }
        return $label . ' — ' . $totals['duration'] . ' ' . __( 'days total', 'tutor-course-search-pro' );
    }

    private function create_order( $user_id, $target_type, $target_id, $tier, $units = 1 ) {
        $plan = $this->plan( $target_type, $tier );
        if ( ! $plan ) return 0;
        $totals = $this->purchase_totals( $plan, $units );
        if ( $this->plan_locked( $user_id, $target_type, $target_id, $tier ) ) return 0;
        if ( $this->has_open_sponsorship( $user_id, $target_type, $target_id ) ) return 0;
        $current_tier = '';
        $current_end = '';
        if ( 'course' === $target_type ) {
            $current_tier = (string) get_post_meta( $target_id, TCSP_Plugin::PROMOTION_TIER_META, true );
            $current_end  = (string) get_post_meta( $target_id, TCSP_Plugin::PROMOTION_END_META, true );
        } else {
            $current_tier = (string) get_user_meta( $target_id, TCSP_Tutors::TIER_META, true );
            $current_end  = (string) get_user_meta( $target_id, TCSP_Tutors::END_META, true );
        }
        $today = current_time( 'Y-m-d' );
        $mode = ( $current_tier && $current_end && $current_end >= $today )
            ? ( $current_tier === $tier ? 'extend' : 'change_plan' )
            : 'new';
        $title = sprintf( '%s sponsorship — %s — %s', $this->plan_label( $target_type, $tier ), $target_type, $this->purchase_label( $plan, $totals['units'] ) );
        $id = wp_insert_post( array( 'post_type' => self::CPT, 'post_status' => 'private', 'post_title' => $title, 'post_author' => $user_id ) );
        if ( ! $id || is_wp_error( $id ) ) return 0;
        update_post_meta( $id, '_tcsp_target_type', $target_type );
        update_post_meta( $id, '_tcsp_target_id', (int) $target_id );
        update_post_meta( $id, '_tcsp_plan', $tier );
        update_post_meta( $id, '_tcsp_units', $totals['units'] );
        update_post_meta( $id, '_tcsp_unit_price', $totals['unit_price'] );
        update_post_meta( $id, '_tcsp_discount_pct', $totals['discount_pct'] );
        update_post_meta( $id, '_tcsp_amount', $totals['amount'] );
        update_post_meta( $id, '_tcsp_duration', $totals['duration'] );
        update_post_meta( $id, '_tcsp_status', 'pending' );
        update_post_meta( $id, '_tcsp_source', 'payment' );
        update_post_meta( $id, '_tcsp_mode', $mode );
        return $id;
    }

    private function order_totals( $order_id ) {
        $units = $this->normalize_units( get_post_meta( $order_id, '_tcsp_units', true ) ?: 1 );
        $type = (string) get_post_meta( $order_id, '_tcsp_target_type', true );
        $tier = (string) get_post_meta( $order_id, '_tcsp_plan', true );
        $plan = $this->plan( $type, $tier );
        if ( ! $plan ) return array( 'units' => $units, 'unit_price' => 0, 'discount_pct' => 0, 'amount' => (float) get_post_meta( $order_id, '_tcsp_amount', true ), 'duration' => max( 1, (int) get_post_meta( $order_id, '_tcsp_duration', true ) ) );
        $totals = $this->purchase_totals( $plan, $units );
        $stored_amount = get_post_meta( $order_id, '_tcsp_amount', true );
        $stored_duration = get_post_meta( $order_id, '_tcsp_duration', true );
        if ( '' !== (string) $stored_amount ) $totals['amount'] = (float) $stored_amount;
        if ( '' !== (string) $stored_duration ) $totals['duration'] = max( 1, (int) $stored_duration );
        return $totals;
    }

    public function handle_frontend_action() {
        if ( ! is_user_logged_in() || ! $this->user_is_instructor( get_current_user_id() ) || empty( $_POST['tcsp_sponsor_action'] ) ) return;
        $nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, self::NONCE ) ) return;
        if ( 'create' !== sanitize_key( wp_unslash( $_POST['tcsp_sponsor_action'] ) ) ) return;
        $type = isset( $_POST['target_type'] ) ? sanitize_key( wp_unslash( $_POST['target_type'] ) ) : '';
        $tier = isset( $_POST['tier'] ) ? sanitize_key( wp_unslash( $_POST['tier'] ) ) : '';
        $units = isset( $_POST['units'] ) ? $this->normalize_units( wp_unslash( $_POST['units'] ) ) : 1;
        $id = isset( $_POST['target_id'] ) ? absint( $_POST['target_id'] ) : 0;
        $user_id = get_current_user_id();
        if ( 'course' !== $type && 'tutor' !== $type ) { $this->redirect_notice( 'invalid' ); }
        if ( ! $this->plan( $type, $tier ) ) { $this->redirect_notice( 'invalid' ); }
        if ( 'tutor' === $type ) { $id = $user_id; }
        else { $owned = $this->own_courses( $user_id ); if ( ! isset( $owned[ $id ] ) ) $this->redirect_notice( 'invalid' ); }
        $order = $this->create_order( $user_id, $type, $id, $tier, $units );
        if ( ! $order ) { $this->redirect_notice( 'exists' ); }

        $checkout_course = 1 === $units ? $this->get_sponsorship_checkout_product( $type, $tier ) : $this->create_one_off_checkout_product( $type, $tier, $this->order_totals( $order )['amount'] );
        if ( ! $checkout_course ) {
            update_post_meta( $order, '_tcsp_status', 'cancelled' );
            $this->redirect_notice( 'checkout_error' );
        }
        update_post_meta( $order, '_tcsp_checkout_course_id', $checkout_course );
        update_user_meta( $user_id, '_tcsp_pending_sponsorship_' . $checkout_course, (int) $order );

        if ( class_exists( '\Tutor\Models\CartModel' ) ) {
            $cart_model = new \Tutor\Models\CartModel();
            if ( method_exists( $cart_model, 'is_course_in_user_cart' ) && $cart_model->is_course_in_user_cart( $user_id, $checkout_course ) ) {
                $cart_model->delete_course_from_cart( $user_id, $checkout_course );
            }
            $cart_row = $cart_model->add_course_to_cart( $user_id, $checkout_course );
            if ( $cart_row ) {
                $this->notify_new_payment_request( $order );
                $checkout_url = class_exists( '\Tutor\Ecommerce\CheckoutController' ) ? \Tutor\Ecommerce\CheckoutController::get_page_url() : '';
                if ( $checkout_url ) {
                    wp_safe_redirect( $checkout_url );
                    exit;
                }
            }
        }


        update_post_meta( $order, '_tcsp_status', 'cancelled' );
        $this->delete_checkout_course( $checkout_course );
        $this->redirect_notice( 'checkout_error' );
    }

    private function user_can_cancel_order( $order_id, $user_id ) {
        $post = get_post( $order_id );
        if ( ! $post || self::CPT !== $post->post_type || (int) $post->post_author !== (int) $user_id ) return false;
        if ( 'manual' !== (string) get_post_meta( $order_id, '_tcsp_source', true ) ) return false;
        return in_array( (string) get_post_meta( $order_id, '_tcsp_status', true ), array( 'pending', 'paid', 'active' ), true );
    }

    private function redirect_frontend_dashboard_notice( $notice ) {
        $url = $this->portal_base_url();
        $url = add_query_arg( array( 'tcsp_sp_tab' => 2, 'tcsp_s_notice' => $notice ), $url );
        wp_safe_redirect( $url );
        exit;
    }

    public function admin_set_request_status( $order_id, $status ) {
        $order_id = absint( $order_id );
        $status = sanitize_key( $status );
        $allowed = array( 'pending', 'paid', 'scheduled', 'active', 'rejected', 'cancelled' );
        if ( ! $order_id || ! in_array( $status, $allowed, true ) ) return false;
        $post = get_post( $order_id );
        if ( ! $post || self::CPT !== $post->post_type ) return false;
        $type = (string) get_post_meta( $order_id, '_tcsp_target_type', true );
        $target = absint( get_post_meta( $order_id, '_tcsp_target_id', true ) );
        $tier = (string) get_post_meta( $order_id, '_tcsp_plan', true );
        if ( ! $this->plan( $type, $tier ) || ! $target ) return false;
        $this->set_order_status( $order_id, $status );
        return true;
    }

    public function admin_actions() {
        if ( ! TCSP_Sponsorship_Manager::can_manage() || empty( $_POST['tcsp_order_action'] ) ) return;
        $nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'tcsp_order_admin' ) ) return;
        $id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
        if ( ! $id || ! $this->manager_can_manage_order( $id, get_current_user_id() ) ) return;
        $requested_action = sanitize_key( wp_unslash( $_POST['tcsp_order_action'] ) );
        if ( 'cancel_manual' === $requested_action ) {
            if ( 'manual' !== (string) get_post_meta( $id, '_tcsp_source', true ) ) return;
            $this->set_order_status( $id, 'cancelled' );
            wp_safe_redirect( add_query_arg( array( 'page' => TCSP_Sponsorship_Manager::PAGE_SLUG, 'tab' => 'requests', 'updated' => 1 ), admin_url( 'admin.php' ) ) ); exit;
        }
        $status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
        if ( ! in_array( $status, array( 'pending','paid','active','expired','rejected','cancelled' ), true ) ) return;
        $this->set_order_status( $id, $status );
        wp_safe_redirect( add_query_arg( array( 'page' => TCSP_Sponsorship_Manager::PAGE_SLUG, 'tab' => 'requests', 'updated' => 1 ), admin_url( 'admin.php' ) ) ); exit;
    }

    private function manager_can_manage_order( $id, $user_id ) {
        if ( user_can( $user_id, 'manage_options' ) ) return true;
        $type = (string) get_post_meta( $id, '_tcsp_target_type', true );
        if ( 'course' !== $type ) return false;
        $tier = (string) get_post_meta( $id, '_tcsp_plan', true );
        $plans = $this->settings->promotion_tiers();
        return isset( $plans[ $tier ]['manager_id'] ) && absint( $plans[ $tier ]['manager_id'] ) === absint( $user_id );
    }

    public function create_manual_sponsorship( $type, $target_id, $tier, $created_by = 0, $activate = true, $units = 1 ) {
        $type = sanitize_key( (string) $type );
        $target_id = absint( $target_id );
        $tier = sanitize_key( (string) $tier );
        $created_by = absint( $created_by );
        $units = $this->normalize_units( $units );
        if ( ! $created_by ) $created_by = get_current_user_id();
        if ( ! TCSP_Sponsorship_Manager::can_manage() ) return 0;
        $plan = $this->plan( $type, $tier );
        if ( ! $plan || ! $target_id ) return 0;
        if ( 'course' === $type ) {
            if ( TCSP_Plugin::COURSE_CPT !== get_post_type( $target_id ) || 'publish' !== get_post_status( $target_id ) ) return 0;
            if ( ! user_can( $created_by, 'manage_options' ) ) {
                $manager_id = absint( $plan['manager_id'] ?? 0 );
                if ( ! $manager_id || $manager_id !== $created_by ) return 0;
            }
        } elseif ( 'tutor' === $type ) {
            if ( ! user_can( $created_by, 'manage_options' ) ) return 0;
            $user = get_userdata( $target_id );
            if ( ! $user || ! in_array( 'tutor_instructor', (array) $user->roles, true ) ) return 0;
        } else return 0;
        $order_id = $this->create_order( 'course' === $type ? (int) get_post_field( 'post_author', $target_id ) : $target_id, $type, $target_id, $tier, $units );
        if ( ! $order_id ) return 0;
        update_post_meta( $order_id, '_tcsp_source', 'manual' );
        update_post_meta( $order_id, '_tcsp_created_by', $created_by );
        if ( $activate ) {
            $this->set_order_status( $order_id, 'active' );
        }
        return $order_id;
    }


    /**
     * Create/update the account-visible sponsorship record for a manual
     * assignment made directly from the admin Courses/Tutors tables.
     */
    public function upsert_manual_assignment_record( $type, $target_id, $tier, $tutor_id, $created_by = 0, $start = '', $end = '' ) {
        $type      = sanitize_key( (string) $type );
        $target_id = absint( $target_id );
        $tier      = sanitize_key( (string) $tier );
        $tutor_id  = absint( $tutor_id );
        $created_by = absint( $created_by ) ?: get_current_user_id();
        $plan = $this->plan( $type, $tier );
        if ( ! $plan || ! $target_id || ! $tutor_id ) return 0;

        // Reuse the newest open/active record for this target. Payment records
        // remain authoritative and should not be duplicated by a manual save.
        $existing = get_posts( array(
            'post_type'      => self::CPT,
            'post_status'    => 'private',
            'posts_per_page' => 10,
            'author'         => $tutor_id,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'meta_query'     => array(
                'relation' => 'AND',
                array( 'key' => '_tcsp_target_type', 'value' => $type ),
                array( 'key' => '_tcsp_target_id', 'value' => $target_id ),
                array( 'key' => '_tcsp_status', 'value' => array( 'pending', 'paid', 'active' ), 'compare' => 'IN' ),
            ),
            'no_found_rows'  => true,
        ) );
        $order_id = 0;
        foreach ( $existing as $candidate ) {
            $source = (string) get_post_meta( $candidate, '_tcsp_source', true );
            if ( 'manual' === $source ) { $order_id = (int) $candidate; break; }
            if ( 'active' === (string) get_post_meta( $candidate, '_tcsp_status', true ) ) { return (int) $candidate; }
        }
        if ( ! $order_id ) {
            $label = isset( $plan['label'] ) ? $plan['label'] : $tier;
            $order_id = wp_insert_post( array(
                'post_type'   => self::CPT,
                'post_status' => 'private',
                'post_title'  => sprintf( '%s sponsorship — %s', $label, $type ),
                'post_author' => $tutor_id,
            ), true );
            if ( is_wp_error( $order_id ) || ! $order_id ) return 0;
        }

        update_post_meta( $order_id, '_tcsp_target_type', $type );
        update_post_meta( $order_id, '_tcsp_target_id', $target_id );
        update_post_meta( $order_id, '_tcsp_plan', $tier );
        update_post_meta( $order_id, '_tcsp_units', 1 );
        update_post_meta( $order_id, '_tcsp_unit_price', (float) $plan['price'] );
        update_post_meta( $order_id, '_tcsp_discount_pct', 0 );
        update_post_meta( $order_id, '_tcsp_amount', (float) $plan['price'] );
        update_post_meta( $order_id, '_tcsp_duration', (int) $plan['duration'] );
        update_post_meta( $order_id, '_tcsp_source', 'manual' );
        update_post_meta( $order_id, '_tcsp_created_by', $created_by );
        update_post_meta( $order_id, '_tcsp_status', 'active' );
        $start = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $start ) ? (string) $start : current_time( 'Y-m-d' );
        $end = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $end ) ? (string) $end : wp_date( 'Y-m-d', current_time( 'timestamp' ) + ( max( 1, (int) $plan['duration'] ) * DAY_IN_SECONDS ) );
        if ( $end < $start ) $end = $start;
        update_post_meta( $order_id, '_tcsp_start', $start );
        update_post_meta( $order_id, '_tcsp_end', $end );
        if ( 'course' === $type ) {
            update_post_meta( $target_id, TCSP_Plugin::PROMOTED_META, 1 );
            update_post_meta( $target_id, TCSP_Plugin::PROMOTION_TIER_META, $tier );
            update_post_meta( $target_id, TCSP_Plugin::PROMOTION_START_META, $start );
            update_post_meta( $target_id, TCSP_Plugin::PROMOTION_END_META, $end );
        } else {
            update_user_meta( $target_id, TCSP_Tutors::PROMOTED_META, 1 );
            update_user_meta( $target_id, TCSP_Tutors::TIER_META, $tier );
            update_user_meta( $target_id, TCSP_Tutors::START_META, $start );
            update_user_meta( $target_id, TCSP_Tutors::END_META, $end );
        }
        return (int) $order_id;
    }

    private function sponsorship_admin_owner() {
        $admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ids' ) );
        return ! empty( $admins ) ? (int) $admins[0] : 0;
    }

    private function sponsorship_product_key( $type, $tier ) {
        return sanitize_key( 'tutor' === $type ? 'tutor-' . $tier : 'course-' . $tier );
    }

    private function get_sponsorship_checkout_product( $type, $tier ) {
        $key = $this->sponsorship_product_key( $type, $tier );
        return absint( get_option( 'tcsp_sponsorship_product_' . $key, 0 ) );
    }

    private function create_one_off_checkout_product( $type, $tier, $amount ) {
        $shared = $this->get_sponsorship_checkout_product( $type, $tier );
        if ( ! $shared || TCSP_Plugin::COURSE_CPT !== get_post_type( $shared ) ) return 0;
        $shared_post = get_post( $shared );
        if ( ! $shared_post ) return 0;
        $product_id = wp_insert_post( array(
            'post_type' => TCSP_Plugin::COURSE_CPT,
            'post_status' => 'publish',
            'post_title' => sprintf( '%s — %s — %s', $shared_post->post_title, __( 'Multi-unit checkout', 'tutor-course-search-pro' ), wp_generate_password( 8, false, false ) ),
            'post_author' => (int) $shared_post->post_author,
            'post_content' => $shared_post->post_content,
            'post_excerpt' => $shared_post->post_excerpt,
        ), true );
        if ( is_wp_error( $product_id ) || ! $product_id ) return 0;
        $all_meta = get_post_meta( $shared );
        foreach ( $all_meta as $meta_key => $values ) {
            if ( in_array( $meta_key, array( '_edit_lock', '_edit_last' ), true ) ) continue;
            foreach ( (array) $values as $value ) add_post_meta( $product_id, $meta_key, maybe_unserialize( $value ) );
        }
        update_post_meta( $product_id, '_tcsp_sponsorship_checkout_product', 1 );
        update_post_meta( $product_id, '_tcsp_sponsorship_one_off', 1 );
        update_post_meta( $product_id, '_tcsp_parent_checkout_product', $shared );
        update_post_meta( $product_id, '_tutor_course_price_type', 'paid' );
        update_post_meta( $product_id, 'tutor_course_price', max( 0, (float) $amount ) );
        update_post_meta( $product_id, 'tutor_course_sale_price', '' );
        update_post_meta( $product_id, '_tutor_is_public_course', 'no' );
        update_post_meta( $product_id, '_tcsp_sponsorship_product_type', $type );
        update_post_meta( $product_id, '_tcsp_sponsorship_product_tier', $tier );
        return (int) $product_id;
    }

    public function ensure_sponsorship_checkout_products() {
        if ( ! class_exists( 'TCSP_Settings' ) || ! function_exists( 'tutor_utils' ) ) return;
        $owner = $this->sponsorship_admin_owner();
        if ( ! $owner ) return;
        foreach ( array( 'course', 'tutor' ) as $type ) {
            $plans = $this->settings->promotion_tiers();
            if ( 'tutor' === $type ) $plans = $this->settings->tutor_promotion_tiers();
            foreach ( $plans as $tier => $plan ) {
                if ( ! is_array( $plan ) ) continue;
                $key = $this->sponsorship_product_key( $type, $tier );
                $product_id = absint( get_option( 'tcsp_sponsorship_product_' . $key, 0 ) );
                if ( ! $product_id || get_post_type( $product_id ) !== TCSP_Plugin::COURSE_CPT ) {
                    $label = isset( $plan['label'] ) ? $plan['label'] : ucfirst( $tier );
                    $title = sprintf( 'Sponsorship Checkout — %s — %s', $type === 'course' ? 'Course' : 'Tutor Profile', $label );
                    $product_id = wp_insert_post( array(
                        'post_type' => TCSP_Plugin::COURSE_CPT,
                        'post_status' => 'publish',
                        'post_title' => $title,
                        'post_author' => $owner,
                        'post_excerpt' => 'Internal Tutor Course Search Pro sponsorship checkout product.',
                    ), true );
                    if ( is_wp_error( $product_id ) ) continue;
                    update_option( 'tcsp_sponsorship_product_' . $key, (int) $product_id, false );
                } else {
                    if ( (int) get_post_field( 'post_author', $product_id ) !== $owner ) wp_update_post( array( 'ID' => $product_id, 'post_author' => $owner ) );
                    if ( 'publish' !== get_post_status( $product_id ) ) wp_update_post( array( 'ID' => $product_id, 'post_status' => 'publish' ) );
                }
                update_post_meta( $product_id, '_tcsp_sponsorship_checkout_product', 1 );
                update_post_meta( $product_id, '_tcsp_sponsorship_product_key', $key );
                update_post_meta( $product_id, '_tcsp_sponsorship_product_type', $type );
                update_post_meta( $product_id, '_tcsp_sponsorship_product_tier', $tier );
                update_post_meta( $product_id, '_tcsp_sponsorship_admin_owner', $owner );
                update_post_meta( $product_id, '_tutor_course_price_type', 'paid' );
                update_post_meta( $product_id, 'tutor_course_price', max( 0, (float) $plan['price'] ) );
                update_post_meta( $product_id, 'tutor_course_sale_price', '' );
                update_post_meta( $product_id, '_tutor_is_public_course', 'no' );
                update_post_meta( $product_id, '_tutor_course_level', 'all_levels' );
                update_post_meta( $product_id, '_tutor_course_duration', 0 );
            }
        }
    }

    /**
     * Final SQL guard for frontend Tutor course queries, including secondary
     * queries used by Tutor instructor public profiles.
     *
     * @param array    $clauses SQL clauses.
     * @param WP_Query $query   Current query.
     * @return array
     */
    public function exclude_checkout_products_from_public_course_sql( $clauses, $query ) {
        if ( is_admin() || ! $query instanceof WP_Query ) {
            return $clauses;
        }

        $post_type = $query->get( 'post_type' );
        $is_course_query = empty( $post_type )
            || TCSP_Plugin::COURSE_CPT === $post_type
            || ( is_array( $post_type ) && in_array( TCSP_Plugin::COURSE_CPT, $post_type, true ) );

        if ( ! $is_course_query || false !== strpos( $clauses['where'], 'tcsp_public_checkout_exclusion' ) ) {
            return $clauses;
        }

        global $wpdb;
        $clauses['where'] .= $wpdb->prepare(
            " AND NOT EXISTS ( SELECT 1 FROM {$wpdb->postmeta} tcsp_public_checkout_exclusion WHERE tcsp_public_checkout_exclusion.post_id = {$wpdb->posts}.ID AND tcsp_public_checkout_exclusion.meta_key = %s AND tcsp_public_checkout_exclusion.meta_value = '1' ) ",
            '_tcsp_sponsorship_checkout_product'
        );

        return $clauses;
    }

    /**
     * Last-resort PHP guard for public Tutor course result arrays. This catches
     * integrations that replace/rebuild the result set after SQL execution.
     *
     * @param WP_Post[] $posts  Query results.
     * @param WP_Query  $query  Current query.
     * @return WP_Post[]
     */
    public function remove_checkout_products_from_public_course_results( $posts, $query ) {
        if ( is_admin() || ! $query instanceof WP_Query || ! is_array( $posts ) ) {
            return $posts;
        }

        $post_type = $query->get( 'post_type' );
        $is_course_query = empty( $post_type )
            || TCSP_Plugin::COURSE_CPT === $post_type
            || ( is_array( $post_type ) && in_array( TCSP_Plugin::COURSE_CPT, $post_type, true ) );

        if ( ! $is_course_query ) {
            return $posts;
        }

        $filtered = array();
        foreach ( $posts as $post ) {
            $post_id = is_object( $post ) && isset( $post->ID ) ? (int) $post->ID : absint( $post );
            if ( ! $post_id || '1' === (string) get_post_meta( $post_id, '_tcsp_sponsorship_checkout_product', true ) ) {
                continue;
            }
            $filtered[] = $post;
        }

        return $filtered;
    }

    public function exclude_checkout_products_from_public_queries( $query ) {
        if ( is_admin() || ! $query instanceof WP_Query ) {
            return;
        }
        $post_type = $query->get( 'post_type' );
        $is_course_query = empty( $post_type ) || TCSP_Plugin::COURSE_CPT === $post_type || ( is_array( $post_type ) && in_array( TCSP_Plugin::COURSE_CPT, $post_type, true ) );
        if ( ! $is_course_query ) {
            return;
        }
        $meta_query = $query->get( 'meta_query' );
        $meta_query = is_array( $meta_query ) ? $meta_query : array();
        $meta_query[] = array(
            'relation' => 'OR',
            array( 'key' => '_tcsp_sponsorship_checkout_product', 'compare' => 'NOT EXISTS' ),
            array( 'key' => '_tcsp_sponsorship_checkout_product', 'value' => '1', 'compare' => '!=' ),
        );
        $query->set( 'meta_query', $meta_query );
    }

    public function offline_payee_for_sponsorship( $author_id, $item_id ) {
        if ( '1' !== (string) get_post_meta( $item_id, '_tcsp_sponsorship_checkout_product', true ) ) return $author_id;
        $owner = absint( get_post_meta( $item_id, '_tcsp_sponsorship_admin_owner', true ) );
        return $owner ? $owner : $author_id;
    }

    public function checkout_item_name( $name, $item_id ) {
        if ( '1' !== (string) get_post_meta( $item_id, '_tcsp_sponsorship_checkout_product', true ) ) return $name;
        $type = (string) get_post_meta( $item_id, '_tcsp_sponsorship_product_type', true );
        $tier = (string) get_post_meta( $item_id, '_tcsp_sponsorship_product_tier', true );
        $label = $this->plan_label( $type, $tier );
        return $label ? sprintf( '%s — %s', __( 'Sponsorship', 'tutor-course-search-pro' ), $label ) : $name;
    }

    public function reconcile_native_orders() {
        if ( ! function_exists( 'tutor_utils' ) ) return;
        global $wpdb;
        $orders = $wpdb->get_results( "SELECT o.id, o.user_id, o.order_status, o.payment_status, oi.item_id FROM {$wpdb->prefix}tutor_orders o INNER JOIN {$wpdb->prefix}tutor_order_items oi ON oi.order_id = o.id WHERE o.created_at_gmt >= UTC_TIMESTAMP() - INTERVAL 90 DAY AND oi.item_id IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_tcsp_sponsorship_checkout_product' AND meta_value='1') ORDER BY o.id DESC LIMIT 200" );
        if ( empty( $orders ) ) return;
        $seen = array();
        foreach ( $orders as $row ) {
            $product = absint( $row->item_id );
            $sponsor_id = 0;
            $pending_key = '_tcsp_pending_sponsorship_' . $product;
            $candidate = absint( get_user_meta( absint( $row->user_id ), $pending_key, true ) );
            if ( $candidate ) {
                $candidate_status = (string) get_post_meta( $candidate, '_tcsp_status', true );
                $candidate_product = absint( get_post_meta( $candidate, '_tcsp_checkout_course_id', true ) );
                if ( in_array( $candidate_status, array( 'pending', 'paid' ), true ) && $candidate_product === $product ) $sponsor_id = $candidate;
            }
            if ( ! $sponsor_id ) {
                $matches = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'private', 'author' => absint( $row->user_id ), 'posts_per_page' => 1, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC', 'meta_query' => array( array( 'key' => '_tcsp_checkout_course_id', 'value' => $product ), array( 'key' => '_tcsp_status', 'value' => array( 'pending', 'paid' ), 'compare' => 'IN' ) ) ) );
                if ( $matches ) $sponsor_id = (int) $matches[0];
            }
            if ( ! $sponsor_id || isset( $seen[ $sponsor_id ] ) ) continue;
            $seen[ $sponsor_id ] = true;
            $payment = strtolower( (string) $row->payment_status );
            $status  = strtolower( (string) $row->order_status );
            if ( 'paid' === $payment && 'completed' === $status ) {
                if ( $this->settings->get( 'sponsorship_auto_activate' ) ) {
                    $this->activate_paid_sponsorship( $sponsor_id, $product, absint( $row->id ) );
                    $this->delete_checkout_course( $product );
                } else {
                    update_post_meta( $sponsor_id, '_tcsp_native_order_id', absint( $row->id ) );
                    $old_sponsor_status = (string) get_post_meta( $sponsor_id, '_tcsp_status', true );
                    update_post_meta( $sponsor_id, '_tcsp_status', 'paid' );
                    if ( 'paid' !== $old_sponsor_status ) $this->notify_assigned_manager_paid( $sponsor_id );
                    $this->delete_checkout_course( $product );
                }
            } elseif ( in_array( $payment, array( 'failed','refunded','partially-refunded' ), true ) || in_array( $status, array( 'cancelled','trash' ), true ) ) {
                $this->set_order_status( $sponsor_id, 'cancelled' );
                $this->delete_checkout_course( $product );
            } else {
                if ( ! in_array( get_post_meta( $sponsor_id, '_tcsp_status', true ), array( 'active', 'paid' ), true ) ) update_post_meta( $sponsor_id, '_tcsp_status', 'pending' );
            }
        }
    }

    private function activate_paid_sponsorship( $sponsor_id, $checkout_course_id, $native_order_id ) {
        $type = (string) get_post_meta( $sponsor_id, '_tcsp_target_type', true );
        $target = absint( get_post_meta( $sponsor_id, '_tcsp_target_id', true ) );
        $tier = (string) get_post_meta( $sponsor_id, '_tcsp_plan', true );
        $plan = $this->plan( $type, $tier );
        if ( ! $plan || ! $target ) return;
        $totals = $this->order_totals( $sponsor_id );
        $days = max( 1, (int) $totals['duration'] );
        $today_ts = current_time( 'timestamp' );
        $today = current_time( 'Y-m-d' );
        $current_tier = 'course' === $type
            ? (string) get_post_meta( $target, TCSP_Plugin::PROMOTION_TIER_META, true )
            : (string) get_user_meta( $target, TCSP_Tutors::TIER_META, true );
        $current_end = 'course' === $type
            ? (string) get_post_meta( $target, TCSP_Plugin::PROMOTION_END_META, true )
            : (string) get_user_meta( $target, TCSP_Tutors::END_META, true );
        $mode = (string) get_post_meta( $sponsor_id, '_tcsp_mode', true );
        if ( ! $mode ) {
            $mode = ( $current_tier && $current_end && $current_end >= $today )
                ? ( $current_tier === $tier ? 'extend' : 'change_plan' )
                : 'new';
            update_post_meta( $sponsor_id, '_tcsp_mode', $mode );
        }
        if ( 'change_plan' === $mode && $current_tier && $current_tier !== $tier && $current_end && $current_end >= $today ) {
            $start_ts = strtotime( $current_end . ' 00:00:00' ) + DAY_IN_SECONDS;
            $start = wp_date( 'Y-m-d', $start_ts );
            $end = wp_date( 'Y-m-d', $start_ts + ( $days * DAY_IN_SECONDS ) );
            update_post_meta( $sponsor_id, '_tcsp_native_order_id', $native_order_id );
            update_post_meta( $sponsor_id, '_tcsp_status', 'scheduled' );
            update_post_meta( $sponsor_id, '_tcsp_start', $start );
            update_post_meta( $sponsor_id, '_tcsp_end', $end );
            $owner_user = (int) get_post_field( 'post_author', $sponsor_id );
            $this->remove_native_enrollment( $checkout_course_id, $owner_user );
            if ( $owner_user ) delete_user_meta( $owner_user, '_tcsp_pending_sponsorship_' . $checkout_course_id );
            $this->delete_checkout_course( $checkout_course_id );
            $this->notify_tutor_status( $sponsor_id, 'scheduled' );
            return;
        }
        $extend = $current_end && $current_end >= $today && $current_tier === $tier;
        $start = $extend ? $current_end : $today;
        $base_ts = $extend ? strtotime( $current_end . ' 00:00:00' ) : $today_ts;
        $end = wp_date( 'Y-m-d', $base_ts + ( $days * DAY_IN_SECONDS ) );
        update_post_meta( $sponsor_id, '_tcsp_native_order_id', $native_order_id );
        $was_active = 'active' === (string) get_post_meta( $sponsor_id, '_tcsp_status', true );
        update_post_meta( $sponsor_id, '_tcsp_status', 'active' );
        update_post_meta( $sponsor_id, '_tcsp_start', $start );
        update_post_meta( $sponsor_id, '_tcsp_end', $end );
        if ( 'course' === $type && class_exists( 'TCSP_Sponsorship_Manager' ) ) {
            update_post_meta( $target, TCSP_Plugin::PROMOTED_META, 1 );
            update_post_meta( $target, TCSP_Plugin::PROMOTION_TIER_META, $tier );
            update_post_meta( $target, TCSP_Plugin::PROMOTION_START_META, $start );
            update_post_meta( $target, TCSP_Plugin::PROMOTION_END_META, $end );
        } elseif ( 'tutor' === $type && class_exists( 'TCSP_Tutors' ) ) {
            update_user_meta( $target, TCSP_Tutors::PROMOTED_META, 1 );
            update_user_meta( $target, TCSP_Tutors::TIER_META, $tier );
            update_user_meta( $target, TCSP_Tutors::START_META, $start );
            update_user_meta( $target, TCSP_Tutors::END_META, $end );
        }
        $this->remove_native_enrollment( $checkout_course_id, (int) get_post_field( 'post_author', $sponsor_id ) );
        $owner_user = (int) get_post_field( 'post_author', $sponsor_id );
        if ( $owner_user ) delete_user_meta( $owner_user, '_tcsp_pending_sponsorship_' . $checkout_course_id );
        if ( ! $was_active ) $this->notify_tutor_status( $sponsor_id, 'active' );
        $this->delete_checkout_course( $checkout_course_id );
    }

    private function remove_native_enrollment( $course_id, $user_id ) {
        if ( ! $course_id || ! $user_id ) return;
        $ids = get_posts( array( 'post_type' => 'tutor_enrolled', 'post_parent' => $course_id, 'author' => $user_id, 'posts_per_page' => 20, 'fields' => 'ids' ) );
        foreach ( $ids as $id ) wp_delete_post( $id, true );
    }

    private function delete_checkout_course( $course_id ) {
        $course_id = absint( $course_id );
        if ( ! $course_id ) return;
        if ( '1' !== (string) get_post_meta( $course_id, '_tcsp_sponsorship_one_off', true ) ) return;
        if ( get_post_meta( $course_id, '_tcsp_sponsorship_checkout_product', true ) ) {
            wp_delete_post( $course_id, true );
        }
    }

    public function cleanup_checkout_course_after_payment() {
        // Reconciliation is intentionally server-side; this hook is only a final cleanup pass.
        if ( is_user_logged_in() && is_page( self::PAGE_SLUG ) ) $this->reconcile_native_orders();
    }



    private function set_order_status( $id, $status ) {
        $old_status = (string) get_post_meta( $id, '_tcsp_status', true );
        if ( $old_status === $status ) return;

        update_post_meta( $id, '_tcsp_status', $status );
        $type = (string) get_post_meta( $id, '_tcsp_target_type', true );
        $target = absint( get_post_meta( $id, '_tcsp_target_id', true ) );
        $tier = (string) get_post_meta( $id, '_tcsp_plan', true );
        $plan = $this->plan( $type, $tier );
        if ( ! $plan || ! $target ) return;

        if ( in_array( $status, array( 'paid', 'active' ), true ) ) {
            $totals = $this->order_totals( $id );
            $days   = max( 1, (int) $totals['duration'] );
            $today  = current_time( 'Y-m-d' );
            $current_tier = 'course' === $type
                ? (string) get_post_meta( $target, TCSP_Plugin::PROMOTION_TIER_META, true )
                : (string) get_user_meta( $target, TCSP_Tutors::TIER_META, true );
            $current_end = 'course' === $type
                ? (string) get_post_meta( $target, TCSP_Plugin::PROMOTION_END_META, true )
                : (string) get_user_meta( $target, TCSP_Tutors::END_META, true );

            $mode = (string) get_post_meta( $id, '_tcsp_mode', true );
            if ( ! $mode ) {
                $mode = ( $current_tier && $current_end && $current_end >= $today )
                    ? ( $current_tier === $tier ? 'extend' : 'change_plan' )
                    : 'new';
                update_post_meta( $id, '_tcsp_mode', $mode );
            }

            // A different plan never replaces an active paid plan immediately.
            // It becomes a scheduled sponsorship and starts the day after the
            // current sponsorship ends.
            if ( 'change_plan' === $mode && $current_end && $current_end >= $today && $current_tier && $current_tier !== $tier ) {
                $start_ts = strtotime( $current_end . ' 00:00:00' ) + DAY_IN_SECONDS;
                $start = wp_date( 'Y-m-d', $start_ts );
                $end   = wp_date( 'Y-m-d', $start_ts + ( $days * DAY_IN_SECONDS ) );
                update_post_meta( $id, '_tcsp_start', $start );
                update_post_meta( $id, '_tcsp_end', $end );
                if ( 'active' === $status ) {
                    // Admin explicitly activating a scheduled upgrade should
                    // still respect the scheduled start rather than hijacking
                    // the currently active promotion.
                    update_post_meta( $id, '_tcsp_status', 'scheduled' );
                }
                return;
            }

            // Scheduled records are activated with their already-computed
            // dates by process_scheduled_sponsorships().
            if ( 'scheduled' === $old_status && 'active' === $status ) {
                $start = (string) get_post_meta( $id, '_tcsp_start', true );
                $end   = (string) get_post_meta( $id, '_tcsp_end', true );
                if ( $start && $end ) {
                    $this->apply_target_assignment( $id, $start, $end );
                    return;
                }
            }

            $extend = $current_end && $current_end >= $today;
            $start = $extend ? $current_end : $today;
            $base_ts = $extend ? strtotime( $current_end . ' 00:00:00' ) : current_time( 'timestamp' );
            $end = wp_date( 'Y-m-d', $base_ts + ( $days * DAY_IN_SECONDS ) );
            update_post_meta( $id, '_tcsp_start', $start );
            update_post_meta( $id, '_tcsp_end', $end );
            $this->apply_target_assignment( $id, $start, $end );
        }

        if ( in_array( $status, array( 'rejected', 'cancelled', 'expired' ), true ) ) {
            // Cancelling/rejecting a future plan must not erase the currently
            // active sponsorship underneath it.
            if ( 'scheduled' !== $old_status ) {
                $this->remove_target_assignment( $type, $target );
            }
        }

        $source = (string) get_post_meta( $id, '_tcsp_source', true );
        if ( in_array( $status, array( 'active', 'scheduled', 'rejected', 'cancelled', 'expired' ), true ) ) {
            $this->notify_tutor_status( $id, $status );
        } elseif ( 'paid' === $status && 'payment' === $source ) {
            $this->notify_assigned_manager_paid( $id );
        }
    }

    private function remove_target_assignment( $type, $target ) {
        if ( ! $target ) return;
        if ( 'course' === $type ) {
            delete_post_meta( $target, TCSP_Plugin::PROMOTED_META );
            delete_post_meta( $target, TCSP_Plugin::PROMOTION_TIER_META );
            delete_post_meta( $target, TCSP_Plugin::PROMOTION_START_META );
            delete_post_meta( $target, TCSP_Plugin::PROMOTION_END_META );
        } elseif ( 'tutor' === $type ) {
            delete_user_meta( $target, TCSP_Tutors::PROMOTED_META );
            delete_user_meta( $target, TCSP_Tutors::TIER_META );
            delete_user_meta( $target, TCSP_Tutors::START_META );
            delete_user_meta( $target, TCSP_Tutors::END_META );
        }
    }

    private function apply_target_assignment( $id, $start, $end ) {
        $type = (string) get_post_meta( $id, '_tcsp_target_type', true );
        $target = absint( get_post_meta( $id, '_tcsp_target_id', true ) );
        $tier = (string) get_post_meta( $id, '_tcsp_plan', true );
        if ( ! $target || ! $tier ) return;
        update_post_meta( $id, '_tcsp_start', $start );
        update_post_meta( $id, '_tcsp_end', $end );
        if ( 'course' === $type ) {
            update_post_meta( $target, TCSP_Plugin::PROMOTED_META, '1' );
            update_post_meta( $target, TCSP_Plugin::PROMOTION_TIER_META, $tier );
            update_post_meta( $target, TCSP_Plugin::PROMOTION_START_META, $start );
            update_post_meta( $target, TCSP_Plugin::PROMOTION_END_META, $end );
        } elseif ( 'tutor' === $type ) {
            update_user_meta( $target, TCSP_Tutors::PROMOTED_META, '1' );
            update_user_meta( $target, TCSP_Tutors::TIER_META, $tier );
            update_user_meta( $target, TCSP_Tutors::START_META, $start );
            update_user_meta( $target, TCSP_Tutors::END_META, $end );
        }
    }

    public function process_scheduled_sponsorships() {
        $today = current_time( 'Y-m-d' );
        $ids = get_posts( array(
            'post_type' => self::CPT,
            'post_status' => 'private',
            'posts_per_page' => 100,
            'fields' => 'ids',
            'meta_query' => array(
                array( 'key' => '_tcsp_status', 'value' => 'scheduled' ),
                array( 'key' => '_tcsp_start', 'value' => $today, 'compare' => '<=', 'type' => 'DATE' ),
            ),
            'orderby' => 'date',
            'order' => 'ASC',
        ) );
        foreach ( $ids as $id ) {
            $start = (string) get_post_meta( $id, '_tcsp_start', true );
            $end = (string) get_post_meta( $id, '_tcsp_end', true );
            if ( ! $start || ! $end ) continue;
            update_post_meta( $id, '_tcsp_status', 'active' );
            $this->apply_target_assignment( $id, $start, $end );
            $this->notify_tutor_status( $id, 'active' );
        }
    }

    private function notifications_enabled() {
        return (bool) $this->settings->get( 'sponsorship_notifications' );
    }

    private function target_label( $id ) {
        $type = (string) get_post_meta( $id, '_tcsp_target_type', true );
        $target = absint( get_post_meta( $id, '_tcsp_target_id', true ) );
        if ( 'course' === $type ) {
            return get_the_title( $target ) ?: __( 'Course', 'tutor-course-search-pro' );
        }
        $u = get_userdata( $target );
        return $u ? $u->display_name : __( 'Tutor profile', 'tutor-course-search-pro' );
    }

    private function notify_new_payment_request( $id ) {
        if ( ! $this->notifications_enabled() ) return;
        $type = (string) get_post_meta( $id, '_tcsp_target_type', true );
        $tier = (string) get_post_meta( $id, '_tcsp_plan', true );
        $manager_ids = array();
        if ( 'course' === $type ) {
            $plans = $this->settings->promotion_tiers();
            $manager_id = isset( $plans[ $tier ]['manager_id'] ) ? absint( $plans[ $tier ]['manager_id'] ) : 0;
            if ( $manager_id ) $manager_ids[] = $manager_id;
        }
        if ( empty( $manager_ids ) ) {
            $manager_ids = get_users( array( 'role' => 'administrator', 'fields' => 'ids' ) );
        }
        $tutor = get_userdata( (int) get_post_field( 'post_author', $id ) );
        $tutor_name = $tutor ? $tutor->display_name : __( 'Tutor', 'tutor-course-search-pro' );
        $target_label = $this->target_label( $id );
        $subject = sprintf( __( 'New sponsorship request: %s', 'tutor-course-search-pro' ), $target_label );
        $message = sprintf( __( "A new sponsorship payment request was created.\n\nTutor: %s\nTarget: %s\nType: %s\nPlan: %s\n\nPlease review it in Tutor LMS → Sponsorship.", 'tutor-course-search-pro' ), $tutor_name, $target_label, ucfirst( $type ), $this->plan_label( $type, $tier ) );
        foreach ( array_unique( array_map( 'absint', $manager_ids ) ) as $manager_id ) {
            $manager = get_userdata( $manager_id );
            if ( $manager && is_email( $manager->user_email ) ) wp_mail( $manager->user_email, $subject, $message );
        }
    }

    private function notify_assigned_manager_paid( $id ) {
        if ( ! $this->notifications_enabled() ) return;
        $type = (string) get_post_meta( $id, '_tcsp_target_type', true );
        if ( 'course' !== $type ) return;
        $tier = (string) get_post_meta( $id, '_tcsp_plan', true );
        $plans = $this->settings->promotion_tiers();
        $manager_id = isset( $plans[ $tier ]['manager_id'] ) ? absint( $plans[ $tier ]['manager_id'] ) : 0;
        if ( ! $manager_id ) return;
        $manager = get_userdata( $manager_id );
        if ( ! $manager || ! is_email( $manager->user_email ) ) return;
        wp_mail( $manager->user_email, __( 'Sponsorship payment received', 'tutor-course-search-pro' ), sprintf( __( "A sponsorship payment has been confirmed and is awaiting sponsorship activation.\n\nTarget: %s\nPlan: %s\n\nReview it in Tutor LMS → Sponsorship.", 'tutor-course-search-pro' ), $this->target_label( $id ), $this->plan_label( $type, $tier ) ) );
    }

    private function notify_tutor_status( $id, $status ) {
        if ( ! $this->notifications_enabled() ) return;
        $tutor = get_userdata( (int) get_post_field( 'post_author', $id ) );
        if ( ! $tutor || ! is_email( $tutor->user_email ) ) return;
        $type = (string) get_post_meta( $id, '_tcsp_target_type', true );
        $tier = (string) get_post_meta( $id, '_tcsp_plan', true );
        $target_label = $this->target_label( $id );
        $subjects = array(
            'active' => __( 'Your sponsorship is now active', 'tutor-course-search-pro' ),
            'scheduled' => __( 'Your sponsorship upgrade is scheduled', 'tutor-course-search-pro' ),
            'rejected' => __( 'Your sponsorship request was rejected', 'tutor-course-search-pro' ),
            'cancelled' => __( 'Your sponsorship was cancelled', 'tutor-course-search-pro' ),
            'expired' => __( 'Your sponsorship has expired', 'tutor-course-search-pro' ),
        );
        $messages = array(
            'active' => sprintf( __( "Your sponsorship for %s is now active.\n\nPlan: %s\nStart: %s\nEnd: %s", 'tutor-course-search-pro' ), $target_label, $this->plan_label( $type, $tier ), get_post_meta( $id, '_tcsp_start', true ), get_post_meta( $id, '_tcsp_end', true ) ),
            'scheduled' => sprintf( __( "Your sponsorship upgrade for %s is scheduled.\n\nPlan: %s\nStarts: %s\nEnds: %s", 'tutor-course-search-pro' ), $target_label, $this->plan_label( $type, $tier ), get_post_meta( $id, '_tcsp_start', true ), get_post_meta( $id, '_tcsp_end', true ) ),
            'rejected' => sprintf( __( "Your sponsorship request for %s was rejected. Please contact the site team if you need more information.", 'tutor-course-search-pro' ), $target_label ),
            'cancelled' => sprintf( __( "Your sponsorship for %s has been cancelled.", 'tutor-course-search-pro' ), $target_label ),
            'expired' => sprintf( __( "Your sponsorship for %s has expired.", 'tutor-course-search-pro' ), $target_label ),
        );
        if ( isset( $subjects[ $status ], $messages[ $status ] ) ) {
            wp_mail( $tutor->user_email, $subjects[ $status ], $messages[ $status ] );
        }
    }

    public function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $posts = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'private', 'posts_per_page' => 200, 'orderby' => 'date', 'order' => 'DESC' ) );
        echo '<div class="wrap"><h1>Sponsorship Orders</h1><p>Separate paid-plan records for courses and tutor profiles. Approve a paid order by changing its status to Paid or Active; this applies the matching promotion only to its target.</p><table class="widefat striped"><thead><tr><th>ID</th><th>Tutor</th><th>Target</th><th>Plan</th><th>Amount</th><th>Dates</th><th>Status</th><th>Save</th></tr></thead><tbody>';
        foreach ( $posts as $p ) {
            $type=(string)get_post_meta($p->ID,'_tcsp_target_type',true);$target=absint(get_post_meta($p->ID,'_tcsp_target_id',true));$tier=(string)get_post_meta($p->ID,'_tcsp_plan',true);$amount=(float)get_post_meta($p->ID,'_tcsp_amount',true);$status=(string)get_post_meta($p->ID,'_tcsp_status',true);$tutor=get_userdata((int)$p->post_author);$label = 'course' === $type ? get_the_title( $target ) : ( $tutor ? $tutor->display_name : 'Tutor #' . $target );$st=(string)get_post_meta($p->ID,'_tcsp_start',true);$en=(string)get_post_meta($p->ID,'_tcsp_end',true);
            echo '<tr><td>#'.(int)$p->ID.'</td><td>'.esc_html($tutor?$tutor->display_name:'Unknown').'</td><td>'.esc_html(ucfirst($type).': '.$label).'</td><td>'.esc_html($this->plan_label($type,$tier)).'</td><td>'.esc_html(number_format_i18n($amount,2)).'</td><td>'.esc_html(trim($st.' → '.$en,' →')).'</td><td><form method="post">'.wp_nonce_field('tcsp_order_admin','_wpnonce',true,false).'<input type="hidden" name="tcsp_order_action" value="status"><input type="hidden" name="order_id" value="'.(int)$p->ID.'"><select name="status">'.implode('',array_map(function($x)use($status){return '<option value="'.esc_attr($x).'" '.selected($status,$x,false).'>'.esc_html(ucfirst($x)).'</option>';},array('pending','paid','active','expired','rejected','cancelled'))).'</select></td><td><button class="button button-primary">Save</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    private function portal_base_url() {
        if ( function_exists( 'tutor_utils' ) ) return tutor_utils()->tutor_dashboard_url( 'tcsp-sponsorship' );
        return home_url( '/' . self::PAGE_SLUG . '/' );
    }

    private function esc_plan_color( $color ) {
        $color = sanitize_hex_color( $color );
        return $color ? $color : '#2271b1';
    }

    private function status_class( $status ) {
        $allowed = array( 'pending', 'paid', 'scheduled', 'active', 'expired', 'rejected', 'cancelled' );
        return in_array( $status, $allowed, true ) ? $status : 'pending';
    }

    private function render_portal_view() {
        if ( ! is_user_logged_in() ) return '<p>' . esc_html__( 'Please log in as a tutor to manage sponsorships.', 'tutor-course-search-pro' ) . '</p>';
        $user_id = get_current_user_id();
        if ( ! $this->user_is_instructor( $user_id ) ) return '<p>' . esc_html__( 'This area is available to instructors only.', 'tutor-course-search-pro' ) . '</p>';
        $course_plans = $this->settings->promotion_tiers();
        $tutor_plans  = $this->settings->tutor_promotion_tiers();
        $courses      = $this->own_courses( $user_id );
        $orders       = $this->orders( $user_id );
        $open_targets = array();
        foreach ( $orders as $o ) {
            $st = (string) get_post_meta( $o->ID, '_tcsp_status', true );
            if ( ! in_array( $st, array( 'pending', 'paid', 'scheduled', 'active' ), true ) ) continue;
            $ot = (string) get_post_meta( $o->ID, '_tcsp_target_type', true );
            $oid = absint( get_post_meta( $o->ID, '_tcsp_target_id', true ) );
            $open_targets[ $ot . ':' . $oid ] = $st;
        }
        $tab = isset( $_GET['tcsp_sp_tab'] ) ? absint( $_GET['tcsp_sp_tab'] ) : 1;
        $tab = in_array( $tab, array( 1, 2 ), true ) ? $tab : 1;
        $notice = isset( $_GET['tcsp_s_notice'] ) ? sanitize_key( wp_unslash( $_GET['tcsp_s_notice'] ) ) : '';
        $notice_text = '';
        if ( 'created' === $notice ) $notice_text = __( 'Sponsorship request created. Continue through Native Tutor LMS checkout to complete payment.', 'tutor-course-search-pro' );
        elseif ( 'exists' === $notice ) $notice_text = __( 'There is already an open sponsorship request for that item.', 'tutor-course-search-pro' );
        elseif ( 'checkout_error' === $notice ) $notice_text = __( 'We could not open the native Tutor LMS checkout. Please check Native eCommerce and its Checkout page.', 'tutor-course-search-pro' );
        elseif ( 'invalid' === $notice ) $notice_text = __( 'That sponsorship request could not be created.', 'tutor-course-search-pro' );
        $base = $this->portal_base_url();
        ob_start(); ?>
        <div class="tcsp-sponsor-portal">
            <style>
            .tcsp-sponsor-portal{max-width:1180px;margin:0 auto;padding:4px 0 30px;color:#1d2327}.tcsp-sp-header{display:flex;justify-content:space-between;gap:18px;align-items:center;margin-bottom:18px}.tcsp-sp-header h2{margin:0;font-size:26px}.tcsp-sp-tabs{display:flex;gap:6px;border-bottom:1px solid #dcdcde;margin-bottom:20px}.tcsp-sp-tab{padding:11px 16px;text-decoration:none;border:1px solid transparent;border-bottom:0;border-radius:8px 8px 0 0;font-weight:600;color:#50575e}.tcsp-sp-tab.active{background:#fff;border-color:#dcdcde;color:#1d2327}.tcsp-sp-alert{padding:12px 14px;border-left:4px solid #2271b1;background:#f6f7f7;border-radius:6px;margin-bottom:18px}.tcsp-sp-section{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px;margin-bottom:20px;box-shadow:0 1px 2px rgba(0,0,0,.03)}.tcsp-sp-section h3{margin:0 0 6px}.tcsp-sp-section>p{color:#646970;margin-top:0}.tcsp-sp-plan-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:14px;width:100%}.tcsp-sp-plan-card{border:1px solid #dcdcde;border-top:4px solid var(--plan-color);border-radius:10px;padding:15px;background:#fff}.tcsp-sp-plan-name{font-weight:700;font-size:17px;color:var(--plan-color);margin-bottom:6px}.tcsp-sp-plan-desc{min-height:42px;color:#50575e;font-size:13px}.tcsp-sp-price{font-size:21px;font-weight:700;margin:10px 0 2px}.tcsp-sp-duration{font-size:12px;color:#646970}.tcsp-sp-course-list{margin-top:16px;border:1px solid #e2e4e7;border-radius:10px;overflow:hidden}.tcsp-sp-course-row{display:grid;grid-template-columns:minmax(220px,1.7fr) minmax(170px,1fr) auto;gap:12px;align-items:center;padding:12px 14px;border-bottom:1px solid #eee}.tcsp-sp-course-row:last-child{border-bottom:0}.tcsp-sp-course-name strong{display:block}.tcsp-sp-course-name small{color:#646970}.tcsp-sp-course-row select{width:100%;max-width:320px}.tcsp-sp-course-row .button{white-space:nowrap}.tcsp-sp-status-list{display:grid;gap:10px}.tcsp-sp-status-item{border:1px solid #e2e4e7;border-radius:10px;padding:14px;background:#fff;display:grid;grid-template-columns:minmax(180px,1.5fr) repeat(5,minmax(80px,.6fr));gap:12px;align-items:center}.tcsp-unit-form{gap:8px}.tcsp-units-select{min-width:78px}.tcsp-live-total{font-size:12px;color:#1d2327;margin-top:4px}.tcsp-units-label{font-size:12px;font-weight:600;display:flex;gap:5px;align-items:center}.tcsp-sp-status-item strong{display:block}.tcsp-sp-muted{font-size:12px;color:#646970}.tcsp-sp-pill{display:inline-block;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:700}.tcsp-sp-pill-active{background:#dcfce7;color:#166534}.tcsp-sp-pill-pending,.tcsp-sp-pill-paid{background:#e0e7ff;color:#3730a3}.tcsp-sp-pill-scheduled{background:#fef3c7;color:#92400e}.tcsp-sp-pill-expired,.tcsp-sp-pill-rejected,.tcsp-sp-pill-cancelled{background:#fee2e2;color:#991b1b}.tcsp-sp-tutor-card{max-width:none}.tcsp-sp-help-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:12px}.tcsp-sp-help-grid>div{padding:12px;border:1px solid #e2e4e7;border-radius:10px;background:#f8fafc}.tcsp-sp-help-grid strong{display:block;margin-bottom:4px}.tcsp-sp-help-grid p{margin:0;color:#50575e;font-size:13px;line-height:1.5}.tcsp-sp-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.tcsp-sp-empty{text-align:center;padding:24px;color:#646970}.tcsp-sp-dashboard-note{background:#f6f7f7;border:1px solid #e2e4e7;border-radius:10px;padding:12px 14px;font-size:13px;margin-bottom:16px}@media(max-width:900px){.tcsp-sp-plan-grid{grid-template-columns:1fr}.tcsp-sp-course-row{grid-template-columns:1fr}.tcsp-sp-status-item{grid-template-columns:1fr 1fr}.tcsp-sp-help-grid{grid-template-columns:1fr}.tcsp-sp-header{align-items:flex-start;flex-direction:column}}
            </style>
            <div class="tcsp-sp-header"><div><h2><?php esc_html_e( 'Sponsorship', 'tutor-course-search-pro' ); ?></h2><div class="tcsp-sp-muted"><?php esc_html_e( 'Promote your courses or tutor profile and track only your own sponsorships.', 'tutor-course-search-pro' ); ?></div></div></div>
            <?php if ( $notice_text ) : ?><div class="tcsp-sp-alert"><?php echo esc_html( $notice_text ); ?></div><?php endif; ?>
            <div class="tcsp-sp-tabs"><a class="tcsp-sp-tab <?php echo 1 === $tab ? 'active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tcsp_sp_tab', 1, $base ) ); ?>"><?php esc_html_e( 'Promote', 'tutor-course-search-pro' ); ?></a><a class="tcsp-sp-tab <?php echo 2 === $tab ? 'active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tcsp_sp_tab', 2, $base ) ); ?>"><?php esc_html_e( 'My Sponsorship Status', 'tutor-course-search-pro' ); ?></a></div>
            <?php if ( 1 === $tab ) : ?>
                <div class="tcsp-sp-section"><h3><?php esc_html_e( 'Course sponsorship plans', 'tutor-course-search-pro' ); ?></h3><p><?php esc_html_e( 'Choose a plan below, then select the plan when promoting a course.', 'tutor-course-search-pro' ); ?></p><div class="tcsp-sp-plan-grid">
                <?php foreach ( $course_plans as $key => $plan ) : ?><div class="tcsp-sp-plan-card" style="--plan-color:<?php echo esc_attr( $this->esc_plan_color( $plan['color'] ?? '' ) ); ?>"><div class="tcsp-sp-plan-name"><?php echo esc_html( $plan['label'] ); ?></div><div class="tcsp-sp-plan-desc"><?php echo esc_html( $plan['description'] ); ?></div><div class="tcsp-sp-price"><?php echo esc_html( number_format_i18n( (float) $plan['price'], 2 ) ); ?></div><div class="tcsp-sp-duration"><?php echo esc_html( (int) $plan['duration'] ); ?> <?php esc_html_e( 'days', 'tutor-course-search-pro' ); ?> / <?php esc_html_e( 'unit', 'tutor-course-search-pro' ); ?></div></div><?php endforeach; ?></div>
                <div class="tcsp-sp-course-list">
                <?php foreach ( $courses as $id => $title ) : ?><?php $course_current_tier=(string)get_post_meta($id,TCSP_Plugin::PROMOTION_TIER_META,true); $course_current_status=isset($open_targets['course:'.(int)$id])?$open_targets['course:'.(int)$id]:''; $course_blocked=in_array($course_current_status,array('pending','paid','scheduled'),true); ?><form method="post" class="tcsp-sp-course-row tcsp-unit-form" data-current-tier="<?php echo esc_attr($course_current_tier); ?>"><div class="tcsp-sp-course-name"><strong><?php echo esc_html( $title ); ?></strong><small><?php echo $course_current_tier ? esc_html(sprintf(__('Currently sponsored: %s','tutor-course-search-pro'),$this->plan_label('course',$course_current_tier))) : esc_html__('Not currently sponsored','tutor-course-search-pro'); ?></small></div><div><select name="tier" class="tcsp-plan-select" required><option value="">Select a plan</option><?php foreach ( $course_plans as $key => $plan ) : $totals=$this->purchase_totals($plan,1); ?><option value="<?php echo esc_attr( $key ); ?>" data-price="<?php echo esc_attr( (float) $plan['price'] ); ?>" data-d3="<?php echo esc_attr( (float)($plan['discount_3']??0) ); ?>" data-d6="<?php echo esc_attr( (float)($plan['discount_6']??0) ); ?>" data-d12="<?php echo esc_attr( (float)($plan['discount_12']??0) ); ?>" data-duration="<?php echo esc_attr( (int)$plan['duration'] ); ?>"><?php echo esc_html( $plan['label'] . ' — ' . number_format_i18n( (float) $plan['price'], 2 ) . ' / unit' ); ?></option><?php endforeach; ?></select></div><div><select name="units" class="tcsp-units-select" data-default="1"><?php foreach ( $this->allowed_unit_options() as $u ) : ?><option value="<?php echo (int)$u; ?>"><?php echo (int)$u; ?></option><?php endforeach; ?></select><div class="tcsp-live-total" aria-live="polite"></div></div><div><?php wp_nonce_field( self::NONCE ); ?><input type="hidden" name="tcsp_sponsor_action" value="create"><input type="hidden" name="target_type" value="course"><input type="hidden" name="target_id" value="<?php echo (int) $id; ?>"><button class="button button-primary tcsp-sponsor-submit" type="submit" <?php disabled( $course_blocked ); ?>><?php echo $course_blocked ? esc_html__( 'Request already open', 'tutor-course-search-pro' ) : ( $course_current_tier ? esc_html__( 'Extend / change plan', 'tutor-course-search-pro' ) : esc_html__( 'Promote', 'tutor-course-search-pro' ) ); ?></button></div></form><?php endforeach; if ( ! $courses ) : ?><div class="tcsp-sp-empty"><?php esc_html_e( 'No published courses are available to promote.', 'tutor-course-search-pro' ); ?></div><?php endif; ?></div></div>
                <div class="tcsp-sp-section tcsp-sp-help"><h3><?php esc_html_e( 'How plan changes work', 'tutor-course-search-pro' ); ?></h3><div class="tcsp-sp-help-grid"><div><strong><?php esc_html_e( 'New promotion', 'tutor-course-search-pro' ); ?></strong><p><?php esc_html_e( 'Choose a plan and units. Your sponsorship starts after payment and activation.', 'tutor-course-search-pro' ); ?></p></div><div><strong><?php esc_html_e( 'Extend the current plan', 'tutor-course-search-pro' ); ?></strong><p><?php esc_html_e( 'Buying the same plan while it is active adds the purchased duration to your current end date. Your existing sponsorship is not replaced.', 'tutor-course-search-pro' ); ?></p></div><div><strong><?php esc_html_e( 'Change or upgrade plan', 'tutor-course-search-pro' ); ?></strong><p><?php esc_html_e( 'Buying a different plan while your current plan is active schedules the new plan to start after the current sponsorship ends. Your current plan stays active until its original end date.', 'tutor-course-search-pro' ); ?></p></div><div><strong><?php esc_html_e( 'Multiple units', 'tutor-course-search-pro' ); ?></strong><p><?php esc_html_e( 'Units multiply both price and duration. For example, 4 units of a 30-day plan gives 120 days. Any configured bulk discount is applied to the purchase total.', 'tutor-course-search-pro' ); ?></p></div></div></div>
                <div class="tcsp-sp-section tcsp-sp-tutor-card"><h3><?php esc_html_e( 'Tutor profile sponsorship', 'tutor-course-search-pro' ); ?></h3><p><?php esc_html_e( 'These plans are separate from course sponsorship and promote your tutor profile in Tutor Search.', 'tutor-course-search-pro' ); ?></p><div class="tcsp-sp-plan-grid" style="grid-template-columns:repeat(3,minmax(0,1fr));">
                <?php foreach ( $tutor_plans as $key => $plan ) : ?><div class="tcsp-sp-plan-card" style="--plan-color:<?php echo esc_attr( $this->esc_plan_color( $plan['color'] ?? '' ) ); ?>"><div class="tcsp-sp-plan-name"><?php echo esc_html( $plan['label'] ); ?></div><div class="tcsp-sp-plan-desc"><?php echo esc_html( $plan['description'] ); ?></div><div class="tcsp-sp-price"><?php echo esc_html( number_format_i18n( (float) $plan['price'], 2 ) ); ?></div><div class="tcsp-sp-duration"><?php echo esc_html( (int) $plan['duration'] ); ?> <?php esc_html_e( 'days', 'tutor-course-search-pro' ); ?> / <?php esc_html_e( 'unit', 'tutor-course-search-pro' ); ?></div><?php $tutor_current_tier=(string)get_user_meta($user_id,TCSP_Tutors::TIER_META,true); $tutor_current_status=isset($open_targets['tutor:'.(int)$user_id])?$open_targets['tutor:'.(int)$user_id]:''; $tutor_blocked=in_array($tutor_current_status,array('pending','paid','scheduled'),true); ?><form method="post" class="tcsp-sp-actions tcsp-unit-form" style="margin-top:12px" data-current-tier="<?php echo esc_attr($tutor_current_tier); ?>"><div class="tcsp-sp-muted"><?php echo $tutor_current_tier ? esc_html(sprintf(__('Current plan: %s','tutor-course-search-pro'),$this->plan_label('tutor',$tutor_current_tier))) : esc_html__('Not currently sponsored','tutor-course-search-pro'); ?></div><?php wp_nonce_field( self::NONCE ); ?><input type="hidden" name="tcsp_sponsor_action" value="create"><input type="hidden" name="target_type" value="tutor"><input type="hidden" name="target_id" value="<?php echo (int) $user_id; ?>"><input type="hidden" name="tier" value="<?php echo esc_attr( $key ); ?>"><label class="tcsp-units-label">Units <select name="units" class="tcsp-units-select"><?php foreach ( $this->allowed_unit_options() as $u ) : ?><option value="<?php echo (int)$u; ?>"><?php echo (int)$u; ?></option><?php endforeach; ?></select></label><div class="tcsp-live-total" data-price="<?php echo esc_attr( (float)$plan['price'] ); ?>" data-d3="<?php echo esc_attr( (float)($plan['discount_3']??0) ); ?>" data-d6="<?php echo esc_attr( (float)($plan['discount_6']??0) ); ?>" data-d12="<?php echo esc_attr( (float)($plan['discount_12']??0) ); ?>" data-duration="<?php echo esc_attr( (int)$plan['duration'] ); ?>" aria-live="polite"></div><button class="button button-primary tcsp-sponsor-submit" type="submit" <?php disabled( $tutor_blocked ); ?>><?php echo $tutor_blocked ? esc_html__( 'Request already open', 'tutor-course-search-pro' ) : ( $tutor_current_tier === $key ? esc_html__( 'Extend current plan', 'tutor-course-search-pro' ) : ( $tutor_current_tier ? esc_html__( 'Change plan', 'tutor-course-search-pro' ) : esc_html__( 'Promote my profile', 'tutor-course-search-pro' ) ) ); ?></button></form></div><?php endforeach; ?></div></div>
            <?php else : ?>
                <div class="tcsp-sp-section"><h3><?php esc_html_e( 'My sponsorship status', 'tutor-course-search-pro' ); ?></h3><p><?php esc_html_e( 'Only sponsorships you purchased or requested are shown here.', 'tutor-course-search-pro' ); ?></p>
                <?php if ( $orders ) : ?><div class="tcsp-sp-status-list"><?php foreach ( $orders as $order ) : $type=(string)get_post_meta($order->ID,'_tcsp_target_type',true);$target=absint(get_post_meta($order->ID,'_tcsp_target_id',true));$tier=(string)get_post_meta($order->ID,'_tcsp_plan',true);$amount=(float)get_post_meta($order->ID,'_tcsp_amount',true);$status=(string)get_post_meta($order->ID,'_tcsp_status',true);$start=(string)get_post_meta($order->ID,'_tcsp_start',true);$end=(string)get_post_meta($order->ID,'_tcsp_end',true);$label='course'===$type?get_the_title($target):__('My Tutor Profile','tutor-course-search-pro');$plan=$this->plan($type,$tier);?><div class="tcsp-sp-status-item"><div><strong><?php echo esc_html($label ? $label : __('Deleted target','tutor-course-search-pro')); ?></strong><span class="tcsp-sp-muted"><?php echo esc_html( ucfirst( $type ) ); ?></span></div><div><span class="tcsp-sp-muted"><?php esc_html_e('Plan','tutor-course-search-pro');?></span><br><?php echo esc_html($plan['label'] ?? $tier);?><?php $order_units=max(1,min(12,absint(get_post_meta($order->ID,'_tcsp_units',true) ?: 1))); $order_mode=(string)get_post_meta($order->ID,'_tcsp_mode',true); ?><span class="tcsp-sp-muted"><br><?php echo esc_html($order_units.' × '.( $order_mode==='extend'?__('extension','tutor-course-search-pro'):($order_mode==='change_plan'?__('scheduled change','tutor-course-search-pro'):__('purchase','tutor-course-search-pro')))); ?></span></div><div><span class="tcsp-sp-muted"><?php esc_html_e('Units','tutor-course-search-pro');?></span><br><?php echo (int) max(1, min(12, absint(get_post_meta($order->ID,'_tcsp_units',true) ?: 1)));?></div><div><span class="tcsp-sp-muted"><?php esc_html_e('Amount','tutor-course-search-pro');?></span><br><?php echo esc_html(number_format_i18n($amount,2));?></div><div><span class="tcsp-sp-muted"><?php esc_html_e('Dates','tutor-course-search-pro');?></span><br><?php echo esc_html(trim($start.' → '.$end,' →'));?></div><div><span class="tcsp-sp-pill tcsp-sp-pill-<?php echo esc_attr($this->status_class($status));?>"><?php echo esc_html(ucfirst($status));?></span></div></div><?php endforeach; ?></div><?php else : ?><div class="tcsp-sp-empty"><?php esc_html_e( 'No sponsorship purchases or requests yet.', 'tutor-course-search-pro' ); ?></div><?php endif; ?></div>
            <?php endif; ?>
        </div>
        <script>
        (function(){
            function money(v){return Number(v||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});}
            function durationText(days,units){days=Number(days||0);units=Number(units||1);var total=days*units;if(days===30)return units+' × '+(units===1?'month':'months')+' ('+total+' days)';if(days===7)return units+' × '+(units===1?'week':'weeks')+' ('+total+' days)';if(days===365)return units+' × '+(units===1?'year':'years')+' ('+total+' days)';return units+' × '+days+' days ('+total+' days)';}
            function refresh(form){var total=form.querySelector('.tcsp-live-total'),units=form.querySelector('.tcsp-units-select'),tier=form.querySelector('.tcsp-plan-select'),button=form.querySelector('.tcsp-sponsor-submit');if(!total||!units)return;var opt=tier&&tier.options[tier.selectedIndex]?tier.options[tier.selectedIndex]:null;var price=opt?Number(opt.dataset.price||0):Number(total.dataset.price||0),d3=opt?Number(opt.dataset.d3||0):Number(total.dataset.d3||0),d6=opt?Number(opt.dataset.d6||0):Number(total.dataset.d6||0),d12=opt?Number(opt.dataset.d12||0):Number(total.dataset.d12||0),dur=opt?Number(opt.dataset.duration||0):Number(total.dataset.duration||0),u=Math.max(1,Number(units.value||1));var disc=u>=12?d12:(u>=6?d6:(u>=3?d3:0));total.textContent=money(price*u*(1-disc/100))+' — '+durationText(dur,u)+(disc?' — '+disc+'% discount':'');if(button&&!button.disabled){var current=form.dataset.currentTier||'',selected=tier?String(tier.value):'';button.textContent=current?(current===selected?'Extend current plan':(selected?'Change plan':'Select a plan')):'Promote';}}
            document.querySelectorAll('.tcsp-sponsor-portal .tcsp-unit-form').forEach(function(form){refresh(form);form.addEventListener('change',function(e){if(e.target.matches('.tcsp-units-select,.tcsp-plan-select'))refresh(form);});});
        })();
        </script>
        <?php return ob_get_clean();
    }

    public function shortcode() {
        return $this->render_portal_view();
    }

}
